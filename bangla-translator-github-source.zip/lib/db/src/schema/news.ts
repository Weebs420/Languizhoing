import { pgTable, serial, text, timestamp, uniqueIndex, index } from "drizzle-orm/pg-core";

export const newsTable = pgTable(
  "news_items",
  {
    id: serial("id").primaryKey(),
    sourceUrl: text("source_url").notNull(),
    titleBn: text("title_bn").notNull(),
    titleEn: text("title_en").notNull(),
    summaryBn: text("summary_bn"),
    summaryEn: text("summary_en"),
    publishedAt: timestamp("published_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("news_source_url_unique").on(t.sourceUrl),
    index("news_published_at_idx").on(t.publishedAt),
  ],
);

export type NewsItem = typeof newsTable.$inferSelect;
export type InsertNewsItem = typeof newsTable.$inferInsert;
