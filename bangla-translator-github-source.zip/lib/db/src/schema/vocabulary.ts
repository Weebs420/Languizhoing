import {
  pgTable,
  serial,
  text,
  varchar,
  boolean,
  timestamp,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

export const vocabularyTable = pgTable(
  "vocabulary",
  {
    id: serial("id").primaryKey(),
    word: text("word").notNull(),
    pos: varchar("pos", { length: 32 }).notNull(),
    cefr: varchar("cefr", { length: 4 }).notNull(),
    inOxford3000: boolean("in_oxford_3000").notNull().default(false),
    inOxford5000: boolean("in_oxford_5000").notNull().default(false),
    audioUk: text("audio_uk"),
    audioUs: text("audio_us"),
    banglaMeaning: text("bangla_meaning"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [
    uniqueIndex("vocabulary_word_pos_unique").on(t.word, t.pos),
    index("vocabulary_cefr_idx").on(t.cefr),
    index("vocabulary_word_idx").on(t.word),
  ],
);

export type VocabularyEntry = typeof vocabularyTable.$inferSelect;
export type InsertVocabularyEntry = typeof vocabularyTable.$inferInsert;
