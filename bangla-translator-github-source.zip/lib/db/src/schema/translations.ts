import { pgTable, serial, text, timestamp, jsonb, varchar, index } from "drizzle-orm/pg-core";

export const translationsTable = pgTable(
  "translations",
  {
    id: serial("id").primaryKey(),
    banglaText: text("bangla_text").notNull(),
    englishText: text("english_text").notNull(),
    literalText: text("literal_text").notNull(),
    notes: jsonb("notes").$type<string[]>().notNull().default([]),
    tone: varchar("tone", { length: 16 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("translations_created_at_idx").on(t.createdAt)],
);

export type Translation = typeof translationsTable.$inferSelect;
export type InsertTranslation = typeof translationsTable.$inferInsert;
