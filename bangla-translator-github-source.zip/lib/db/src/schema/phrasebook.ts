import { pgTable, serial, text, timestamp, varchar, uniqueIndex, index } from "drizzle-orm/pg-core";

export const phrasebookTable = pgTable(
  "phrasebook",
  {
    id: serial("id").primaryKey(),
    bangla: text("bangla").notNull(),
    english: text("english").notNull(),
    category: varchar("category", { length: 32 }).notNull(),
    example: text("example"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("phrasebook_bangla_unique").on(t.bangla),
    index("phrasebook_category_idx").on(t.category),
  ],
);

export type PhrasebookEntry = typeof phrasebookTable.$inferSelect;
export type InsertPhrasebookEntry = typeof phrasebookTable.$inferInsert;
