import {
  pgTable,
  serial,
  text,
  varchar,
  integer,
  timestamp,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

// Bangla Academy Adhunik Bangla Ovidhan — Postgres translation of the
// reference MySQL schema. One word can have many meanings, examples,
// synonyms, and antonyms.
export const dictionaryWordsTable = pgTable(
  "dictionary_words",
  {
    id: serial("id").primaryKey(),
    word: text("word").notNull(),
    pronunciation: varchar("pronunciation", { length: 255 }),
    partOfSpeech: varchar("part_of_speech", { length: 100 }),
    origin: text("origin"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [
    uniqueIndex("dictionary_words_word_unique").on(t.word),
    index("dictionary_words_pos_idx").on(t.partOfSpeech),
  ],
);

export const dictionaryMeaningsTable = pgTable(
  "dictionary_meanings",
  {
    id: serial("id").primaryKey(),
    wordId: integer("word_id")
      .notNull()
      .references(() => dictionaryWordsTable.id, { onDelete: "cascade" }),
    meaning: text("meaning").notNull(),
    meaningOrder: integer("meaning_order").notNull().default(1),
  },
  (t) => [index("dictionary_meanings_word_idx").on(t.wordId)],
);

export const dictionaryExamplesTable = pgTable(
  "dictionary_examples",
  {
    id: serial("id").primaryKey(),
    wordId: integer("word_id")
      .notNull()
      .references(() => dictionaryWordsTable.id, { onDelete: "cascade" }),
    example: text("example").notNull(),
  },
  (t) => [index("dictionary_examples_word_idx").on(t.wordId)],
);

export const dictionarySynonymsTable = pgTable(
  "dictionary_synonyms",
  {
    id: serial("id").primaryKey(),
    wordId: integer("word_id")
      .notNull()
      .references(() => dictionaryWordsTable.id, { onDelete: "cascade" }),
    synonym: varchar("synonym", { length: 255 }).notNull(),
  },
  (t) => [index("dictionary_synonyms_word_idx").on(t.wordId)],
);

export const dictionaryAntonymsTable = pgTable(
  "dictionary_antonyms",
  {
    id: serial("id").primaryKey(),
    wordId: integer("word_id")
      .notNull()
      .references(() => dictionaryWordsTable.id, { onDelete: "cascade" }),
    antonym: varchar("antonym", { length: 255 }).notNull(),
  },
  (t) => [index("dictionary_antonyms_word_idx").on(t.wordId)],
);

export type DictionaryWord = typeof dictionaryWordsTable.$inferSelect;
export type InsertDictionaryWord = typeof dictionaryWordsTable.$inferInsert;
export type DictionaryMeaning = typeof dictionaryMeaningsTable.$inferSelect;
export type DictionaryExample = typeof dictionaryExamplesTable.$inferSelect;
