import {
  pgTable,
  serial,
  text,
  varchar,
  integer,
  index,
} from "drizzle-orm/pg-core";

// Bangla grammar reference — chapters → sections → topics → rules + examples.
// Postgres translation of the reference MySQL schema.
export const grammarChaptersTable = pgTable("grammar_chapters", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  ordinal: integer("ordinal").notNull().default(1),
});

export const grammarSectionsTable = pgTable(
  "grammar_sections",
  {
    id: serial("id").primaryKey(),
    chapterId: integer("chapter_id")
      .notNull()
      .references(() => grammarChaptersTable.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 255 }).notNull(),
    ordinal: integer("ordinal").notNull().default(1),
  },
  (t) => [index("grammar_sections_chapter_idx").on(t.chapterId)],
);

export const grammarTopicsTable = pgTable(
  "grammar_topics",
  {
    id: serial("id").primaryKey(),
    sectionId: integer("section_id")
      .notNull()
      .references(() => grammarSectionsTable.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 255 }).notNull(),
    content: text("content").notNull(),
    ordinal: integer("ordinal").notNull().default(1),
  },
  (t) => [index("grammar_topics_section_idx").on(t.sectionId)],
);

export const grammarRulesTable = pgTable(
  "grammar_rules",
  {
    id: serial("id").primaryKey(),
    topicId: integer("topic_id")
      .notNull()
      .references(() => grammarTopicsTable.id, { onDelete: "cascade" }),
    ruleText: text("rule_text").notNull(),
  },
  (t) => [index("grammar_rules_topic_idx").on(t.topicId)],
);

export const grammarExamplesTable = pgTable(
  "grammar_examples",
  {
    id: serial("id").primaryKey(),
    topicId: integer("topic_id")
      .notNull()
      .references(() => grammarTopicsTable.id, { onDelete: "cascade" }),
    exampleText: text("example_text").notNull(),
    explanation: text("explanation"),
  },
  (t) => [index("grammar_examples_topic_idx").on(t.topicId)],
);

export type GrammarChapter = typeof grammarChaptersTable.$inferSelect;
export type GrammarSection = typeof grammarSectionsTable.$inferSelect;
export type GrammarTopic = typeof grammarTopicsTable.$inferSelect;
export type GrammarRule = typeof grammarRulesTable.$inferSelect;
export type GrammarExample = typeof grammarExamplesTable.$inferSelect;
