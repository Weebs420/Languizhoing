"""Double-fork daemon wrapper around translate_vocabulary.run().

Detaches from the calling shell so the translation continues even after the
agent's tool-call shell exits. Logs to /tmp/vocab-translate.log.
"""

import os
import sys


def daemonize(logfile: str) -> None:
    if os.fork() > 0:
        os._exit(0)

    os.setsid()

    if os.fork() > 0:
        os._exit(0)

    sys.stdout.flush()
    sys.stderr.flush()

    with open("/dev/null", "rb") as devnull_in:
        os.dup2(devnull_in.fileno(), 0)

    with open(logfile, "ab", buffering=0) as log:
        os.dup2(log.fileno(), 1)
        os.dup2(log.fileno(), 2)


if __name__ == "__main__":
    daemonize("/tmp/vocab-translate.log")
    print(f"[daemon] pid={os.getpid()} starting", flush=True)
    from translate_vocabulary import run

    run(batch_size=150, max_batches=9999)
    print("[daemon] finished", flush=True)
