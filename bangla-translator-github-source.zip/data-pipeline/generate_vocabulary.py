"""Add newly generated English vocabulary with Bangla meanings.

The Oxford import is intentionally kept separate from this job. Oxford gives
the app a stable core list; this job grows the list every day with useful
learner vocabulary that is not already present.

The job is safe to rerun:
* the database unique index protects (word, part of speech)
* generated entries are inserted only when they are genuinely new
* a failed run rolls back its transaction
"""

from __future__ import annotations

import re
import sys
from typing import Any

from db import get_connection
from llm import complete_json

TARGET_NEW_WORDS = 50
MAX_ATTEMPTS = 10
VALID_POS = {
    "adjective",
    "adverb",
    "conjunction",
    "determiner",
    "interjection",
    "noun",
    "preposition",
    "pronoun",
    "verb",
}
VALID_CEFR = {"a1", "a2", "b1", "b2", "c1", "c2"}
WORD_RE = re.compile(r"^[A-Za-z][A-Za-z-]{1,39}$")
BENGALI_RE = re.compile(r"[\u0980-\u09FF]")

SYSTEM = """You are an English vocabulary editor for a Bangla learning app.
Generate useful, natural English words for learners and give their common
Bangla meanings.

Return strictly valid JSON: an array of objects with exactly these fields:
  {"word": "...", "pos": "...", "cefr": "a1|a2|b1|b2|c1|c2", "bn": "..."}

Rules:
* Use one English word, not a sentence or phrase.
* Use lowercase English spelling.
* `pos` must be one of: adjective, adverb, conjunction, determiner,
  interjection, noun, preposition, pronoun, verb.
* Match the Bangla meaning to the part of speech.
* Use Bengali script only for `bn`; no transliteration or English.
* Give one short everyday meaning, or at most three meanings separated by " / ".
* Prefer useful modern words that a learner will encounter in real life.
* Do not include proper names, abbreviations, profanity, or duplicate words.
* No explanations, examples, markdown, or code fences."""

USER_TEMPLATE = """Generate {count} fresh English vocabulary words with Bangla
meanings. None of the words should appear in this existing vocabulary list:

{existing}

Also avoid words already proposed in this run:
{proposed}

Prefer words from this focus area for this batch: {focus}.
The blocked list is authoritative: do not reuse a word even with a different
part of speech.

Return one JSON object per word."""


def fetch_existing(cur) -> set[str]:
    cur.execute("SELECT LOWER(word) FROM vocabulary")
    return {row[0] for row in cur.fetchall()}


def fetch_existing_words(cur) -> list[str]:
    cur.execute("SELECT LOWER(word) FROM vocabulary ORDER BY word")
    return [row[0] for row in cur.fetchall()]


def normalise_entry(item: Any) -> tuple[str, str, str, str] | None:
    if not isinstance(item, dict):
        return None

    word = str(item.get("word") or "").strip().lower()
    pos = str(item.get("pos") or "").strip().lower()
    cefr = str(item.get("cefr") or "").strip().lower()
    bn = str(item.get("bn") or "").strip()

    if not WORD_RE.fullmatch(word):
        return None
    if pos not in VALID_POS or cefr not in VALID_CEFR:
        return None
    if not BENGALI_RE.search(bn) or len(bn) > 160:
        return None
    return word, pos, cefr, bn


def request_batch(
    count: int,
    existing: list[str],
    proposed: set[str],
    focus: str,
) -> list[tuple[str, str, str, str]]:
    existing_text = ", ".join(existing)
    proposed_text = (
        ", ".join(sorted(proposed))
        or "(none)"
    )
    result = complete_json(
        SYSTEM,
        USER_TEMPLATE.format(
            count=count,
            existing=existing_text or "(empty)",
            proposed=proposed_text,
            focus=focus,
        ),
        max_tokens=8192,
    )
    if not isinstance(result, list):
        raise ValueError(f"Expected a JSON list, got {type(result).__name__}")

    entries: list[tuple[str, str, str, str]] = []
    seen: set[str] = set()
    for item in result:
        entry = normalise_entry(item)
        if not entry:
            continue
        key = entry[0]
        if key not in seen:
            seen.add(key)
            entries.append(entry)
    return entries


def insert_entries(cur, entries: list[tuple[str, str, str, str]]) -> int:
    inserted = 0
    # Preserve the current database order, but make every future batch enter
    # alphabetically so newly added words remain predictable.
    for word, pos, cefr, bn in sorted(entries, key=lambda entry: (entry[0], entry[1])):
        cur.execute(
            """
            INSERT INTO vocabulary
              (word, pos, cefr, in_oxford_3000, in_oxford_5000, bangla_meaning)
            VALUES (%s, %s, %s, FALSE, FALSE, %s)
            ON CONFLICT (word, pos) DO NOTHING
            RETURNING id
            """,
            (word, pos, cefr, bn),
        )
        if cur.fetchone():
            inserted += 1
    return inserted


def run(target: int = TARGET_NEW_WORDS) -> int:
    if target < 1:
        raise ValueError("target must be at least 1")

    inserted_total = 0
    proposed: set[str] = set()
    focus_areas = (
        "modern digital life and media",
        "workplace and business",
        "health and science",
        "environment and society",
        "travel, culture, and everyday conversation",
    )

    with get_connection() as conn, conn.cursor() as cur:
        existing_words = fetch_existing(cur)
        for attempt in range(1, MAX_ATTEMPTS + 1):
            remaining = target - inserted_total
            if remaining <= 0:
                break

            requested = max(remaining + 25, 75)
            print(
                f"  vocabulary attempt {attempt}: requesting {requested} words…",
                flush=True,
            )
            candidates = request_batch(
                requested,
                fetch_existing_words(cur),
                proposed,
                focus_areas[(attempt - 1) % len(focus_areas)],
            )

            fresh = [
                entry
                for entry in candidates
                if entry[0] not in existing_words and entry[0] not in proposed
            ]
            proposed.update(entry[0] for entry in candidates)
            inserted = insert_entries(cur, fresh)
            inserted_total += inserted
            existing_words.update(entry[0] for entry in fresh)
            print(
                f"    inserted {inserted} new words; total {inserted_total}/{target}",
                flush=True,
            )

        if inserted_total < target:
            raise RuntimeError(
                f"Only inserted {inserted_total} new vocabulary words; "
                f"the daily target is {target}."
            )

    return inserted_total


if __name__ == "__main__":
    try:
        run()
    except Exception as exc:  # noqa: BLE001
        print(f"generate_vocabulary failed: {exc}", file=sys.stderr)
        sys.exit(1)