"""Use Claude to expand the Bangla → American English phrasebook.

Adds new idioms, slang, and conversational phrases that aren't already in the
phrasebook table. Safe to run repeatedly — duplicates are skipped via the
unique index on `bangla`.
"""

from __future__ import annotations

import sys

from db import get_connection
from llm import complete_json

SYSTEM = """You are a bilingual lexicographer specializing in spoken Bangla
(both Bangladeshi and West Bengali) and American English.

Produce JSON: a list of objects with these exact fields:
- "bangla": the Bangla phrase, idiom, or slang (in Bangla script)
- "english": the natural American English equivalent (not a literal translation)
- "category": one of "idiom", "slang", "genz", "banglish", "regional", "filler", "interjection"
- "example": one short Bangla example sentence using the phrase

Cover Gen Z slang (প্যারা, চিল, কোপ, ছ্যাঁকা, সেই), filler words (মানে, আসলে),
banglish hybrids ("manage করা"), regional dialect (ঢাকাইয়া, সিলেটি, চাটগাঁইয়া),
common idioms, and interjections (আরে, ধুর, ইশ).

Return strictly valid JSON. No prose, no code fences."""


USER_TEMPLATE = """Generate {count} fresh Bangla phrases that are NOT in this existing list:

{existing}

Prioritize phrases an American learner would hear in casual conversation,
text messages, or social media. Vary the categories. Avoid formal/literary
phrases."""


def fetch_existing(cur, limit: int = 500) -> list[str]:
    cur.execute(
        "SELECT bangla FROM phrasebook ORDER BY created_at DESC LIMIT %s",
        (limit,),
    )
    return [row[0] for row in cur.fetchall()]


def insert_entries(cur, entries: list[dict]) -> int:
    inserted = 0
    for entry in entries:
        bangla = (entry.get("bangla") or "").strip()
        english = (entry.get("english") or "").strip()
        category = (entry.get("category") or "idiom").strip().lower()[:32]
        example = (entry.get("example") or "").strip() or None
        if not bangla or not english:
            continue
        cur.execute(
            """
            INSERT INTO phrasebook (bangla, english, category, example)
            VALUES (%s, %s, %s, %s)
            ON CONFLICT (bangla) DO NOTHING
            """,
            (bangla, english, category, example),
        )
        if cur.rowcount > 0:
            inserted += 1
    return inserted


def run(batch_size: int = 50, max_attempts: int = 4) -> int:
    """Insert at least ``batch_size`` new entries, retrying around duplicates."""
    inserted_total = 0

    with get_connection() as conn:
        cur = conn.cursor()
        for attempt in range(1, max_attempts + 1):
            remaining = batch_size - inserted_total
            if remaining <= 0:
                break

            request_count = max(remaining + 20, 60)
            existing = fetch_existing(cur)
            existing_text = "\n".join(f"- {p}" for p in existing) or "(empty)"
            prompt = USER_TEMPLATE.format(
                count=request_count,
                existing=existing_text,
            )
            result = complete_json(SYSTEM, prompt)

            entries = result if isinstance(result, list) else result.get("entries", [])
            if not isinstance(entries, list):
                raise ValueError("Model output was not a list")

            inserted = insert_entries(cur, entries)
            inserted_total += inserted
            print(
                f"  phrasebook attempt {attempt}: inserted {inserted}; "
                f"total {inserted_total}/{batch_size}",
                flush=True,
            )

        if inserted_total < batch_size:
            raise RuntimeError(
                f"Only inserted {inserted_total} new phrasebook entries; "
                f"the daily target is {batch_size}."
            )

    return inserted_total


if __name__ == "__main__":
    try:
        run()
    except Exception as exc:  # noqa: BLE001
        print(f"expand_phrasebook failed: {exc}", file=sys.stderr)
        sys.exit(1)
