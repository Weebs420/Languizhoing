"""Translate Oxford 3000/5000 English vocabulary into Bangla.

For every row in `vocabulary` where `bangla_meaning IS NULL`, asks Claude for
a short, natural Bangla equivalent that respects the part-of-speech (so the
verb `run` becomes "দৌড়ানো", not the noun "দৌড়").

Idempotent and resumable: skip-by-NULL means rerunning continues where the
last run left off. Safe to run as a scheduled deployment.

Usage:
  uv run python translate_vocabulary.py [--batch 80] [--max-batches 9999]
"""

from __future__ import annotations

import argparse
import sys
import time

from db import get_connection
from llm import complete_json

SYSTEM = """You are a bilingual lexicographer. For each English word with its
part of speech, give the most common Bangla meaning.

Rules:
  * The Bangla translation must match the part of speech. For "run" (verb) →
    "দৌড়ানো" (not the noun "দৌড়"). For "light" (adjective) → "হালকা".
  * Output Bangla in Bengali script only — no transliteration, no English.
  * One short translation per word — the most common everyday meaning. If
    multiple meanings are equally common, separate them with " / " (max 3).
  * Do NOT add explanations, examples, or quotes.

Output strictly valid JSON: an array of objects with exactly two fields:
  {"id": <integer>, "bn": "<bangla translation>"}

No prose, no markdown, no code fences — JSON only."""


USER_TEMPLATE = """Translate these {count} English words into Bangla.
Match the part of speech.

{rows}

Return JSON array with id and bn for every word."""


def fetch_pending(cur, limit: int) -> list[tuple[int, str, str]]:
    cur.execute(
        """
        SELECT id, word, pos
        FROM vocabulary
        WHERE bangla_meaning IS NULL
        ORDER BY id
        LIMIT %s
        """,
        (limit,),
    )
    return cur.fetchall()


def translate_batch(rows: list[tuple[int, str, str]]) -> dict[int, str]:
    listing = "\n".join(f'  {{"id": {wid}, "word": "{w}", "pos": "{p}"}}' for wid, w, p in rows)
    prompt = USER_TEMPLATE.format(count=len(rows), rows=listing)
    result = complete_json(SYSTEM, prompt, max_tokens=8192)
    if not isinstance(result, list):
        raise ValueError(f"Expected list, got {type(result).__name__}")
    out: dict[int, str] = {}
    for item in result:
        if not isinstance(item, dict):
            continue
        wid = item.get("id")
        bn = (item.get("bn") or "").strip()
        if isinstance(wid, int) and bn:
            out[wid] = bn
    return out


def update(cur, translations: dict[int, str]) -> int:
    if not translations:
        return 0
    for wid, bn in translations.items():
        cur.execute(
            "UPDATE vocabulary SET bangla_meaning = %s WHERE id = %s AND bangla_meaning IS NULL",
            (bn, wid),
        )
    return len(translations)


def run(batch_size: int = 80, max_batches: int = 9999) -> int:
    total_done = 0
    total_failed = 0

    for batch_no in range(1, max_batches + 1):
        with get_connection() as conn, conn.cursor() as cur:
            rows = fetch_pending(cur, batch_size)
            if not rows:
                print(f"All vocabulary translated. Total this run: {total_done}")
                return total_done

            print(f"  batch {batch_no}: translating {len(rows)} words…", flush=True)
            t0 = time.time()
            try:
                mapping = translate_batch(rows)
            except Exception as exc:  # noqa: BLE001
                total_failed += 1
                print(f"    batch failed: {exc}", file=sys.stderr)
                if total_failed >= 3:
                    print("    too many failures, stopping", file=sys.stderr)
                    return total_done
                time.sleep(2)
                continue

            updated = update(cur, mapping)
            total_done += updated
            elapsed = time.time() - t0
            print(
                f"    saved {updated}/{len(rows)} ({elapsed:.1f}s); running total {total_done}",
                flush=True,
            )

    return total_done


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--batch", type=int, default=80)
    p.add_argument("--max-batches", type=int, default=9999)
    args = p.parse_args()
    try:
        run(args.batch, args.max_batches)
    except KeyboardInterrupt:
        print("\nInterrupted — progress is saved.")
