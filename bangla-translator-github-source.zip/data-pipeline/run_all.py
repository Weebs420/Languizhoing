"""Run every data-pipeline job in sequence.

Useful for cron, scheduled deployments, or a one-shot manual refresh.
"""

from __future__ import annotations

import sys

import expand_phrasebook
import fetch_news
import fetch_vocabulary
import generate_vocabulary
import seed_dictionary
import seed_grammar


def main() -> None:
    failures = 0

    print("== expand_phrasebook ==")
    try:
        expand_phrasebook.run(batch_size=50)
    except Exception as exc:  # noqa: BLE001
        failures += 1
        print(f"expand_phrasebook failed: {exc}", file=sys.stderr)

    print("\n== generate_vocabulary ==")
    try:
        generate_vocabulary.run(target=50)
    except Exception as exc:  # noqa: BLE001
        failures += 1
        print(f"generate_vocabulary failed: {exc}", file=sys.stderr)

    print("\n== fetch_news ==")
    try:
        fetch_news.run()
    except Exception as exc:  # noqa: BLE001
        failures += 1
        print(f"fetch_news failed: {exc}", file=sys.stderr)

    print("\n== fetch_vocabulary ==")
    try:
        fetch_vocabulary.run()
    except Exception as exc:  # noqa: BLE001
        failures += 1
        print(f"fetch_vocabulary failed: {exc}", file=sys.stderr)

    print("\n== seed_grammar ==")
    try:
        seed_grammar.run()
    except Exception as exc:  # noqa: BLE001
        failures += 1
        print(f"seed_grammar failed: {exc}", file=sys.stderr)

    print("\n== seed_dictionary ==")
    try:
        seed_dictionary.run()
    except Exception as exc:  # noqa: BLE001
        failures += 1
        print(f"seed_dictionary failed: {exc}", file=sys.stderr)

    if failures:
        sys.exit(1)


if __name__ == "__main__":
    main()
