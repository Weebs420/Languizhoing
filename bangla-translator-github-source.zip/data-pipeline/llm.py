"""Anthropic client wrapper for the data pipeline."""

from __future__ import annotations

import json
import os
import re
from typing import Any

from anthropic import Anthropic

_BASE_URL = os.environ.get("AI_INTEGRATIONS_ANTHROPIC_BASE_URL")
_API_KEY = os.environ.get("AI_INTEGRATIONS_ANTHROPIC_API_KEY")

if not _BASE_URL or not _API_KEY:
    raise RuntimeError(
        "Anthropic AI integration env vars are missing. "
        "Set AI_INTEGRATIONS_ANTHROPIC_BASE_URL and AI_INTEGRATIONS_ANTHROPIC_API_KEY."
    )

client = Anthropic(api_key=_API_KEY, base_url=_BASE_URL)

MODEL = "claude-sonnet-4-6"


def complete_json(system: str, user: str, max_tokens: int = 8192) -> Any:
    """Call Claude and parse the first JSON object/array out of the response."""
    message = client.messages.create(
        model=MODEL,
        max_tokens=max_tokens,
        system=system,
        messages=[{"role": "user", "content": user}],
    )
    parts = []
    for block in message.content:
        if getattr(block, "type", None) == "text":
            parts.append(block.text)
    raw = "".join(parts).strip()

    # Find the first JSON object or array block in the text.
    match = re.search(r"(\{[\s\S]*\}|\[[\s\S]*\])", raw)
    if not match:
        raise ValueError(f"Model did not return JSON: {raw[:300]}")
    return json.loads(match.group(1))
