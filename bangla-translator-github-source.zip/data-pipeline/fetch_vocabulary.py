"""Scrape the Oxford 3000/5000 word list and load it into the `vocabulary` table.

Source: https://www.oxfordlearnersdictionaries.com/wordlists/oxford3000-5000

Each <li data-hw="..."> entry exposes:
  * data-hw          → headword (the actual word)
  * data-ox3000      → CEFR level if it belongs to the Oxford 3000 (e.g. "a1")
  * data-ox5000      → CEFR level if it belongs to the Oxford 5000 (e.g. "b2")
  * <span class="pos">       → part of speech (verb, noun, …)
  * <span class="belong-to"> → CEFR level shown in the badge
  * .pron-uk[data-src-mp3]   → UK audio
  * .pron-us[data-src-mp3]   → US audio

This script is idempotent: rerunning it upserts every row by (word, pos).
"""

from __future__ import annotations

import sys
import time
from typing import Iterable

import requests
from bs4 import BeautifulSoup

from db import get_connection

URL = "https://www.oxfordlearnersdictionaries.com/wordlists/oxford3000-5000"
USER_AGENT = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
)

VALID_CEFR = {"a1", "a2", "b1", "b2", "c1", "c2"}


def fetch_html() -> str:
    headers = {"User-Agent": USER_AGENT, "Accept": "text/html"}
    for attempt in range(3):
        try:
            r = requests.get(URL, headers=headers, timeout=60)
            r.raise_for_status()
            return r.text
        except Exception as exc:  # noqa: BLE001
            if attempt == 2:
                raise
            print(f"  fetch attempt {attempt + 1} failed: {exc}; retrying…")
            time.sleep(2 * (attempt + 1))
    raise RuntimeError("unreachable")


def normalise_cefr(value: str | None) -> str | None:
    if not value:
        return None
    v = value.strip().lower()
    return v if v in VALID_CEFR else None


def parse_entries(html: str) -> list[dict]:
    soup = BeautifulSoup(html, "html.parser")
    entries: list[dict] = []
    seen: set[tuple[str, str]] = set()

    for li in soup.select("li[data-hw]"):
        word = (li.get("data-hw") or "").strip()
        if not word:
            continue

        anchor = li.find("a")
        if anchor and anchor.get_text(strip=True):
            word = anchor.get_text(strip=True)

        pos_node = li.find("span", class_="pos")
        pos = (pos_node.get_text(strip=True) if pos_node else "").lower() or "—"

        ox3000 = normalise_cefr(li.get("data-ox3000"))
        ox5000 = normalise_cefr(li.get("data-ox5000"))
        in_ox_3000 = ox3000 is not None
        in_ox_5000 = ox5000 is not None or ox3000 is not None

        badge_node = li.find("span", class_="belong-to")
        badge = normalise_cefr(badge_node.get_text(strip=True) if badge_node else None)
        cefr = badge or ox3000 or ox5000
        if not cefr:
            continue

        uk_node = li.select_one(".pron-uk")
        us_node = li.select_one(".pron-us")
        audio_uk = uk_node.get("data-src-mp3") if uk_node else None
        audio_us = us_node.get("data-src-mp3") if us_node else None

        key = (word.lower(), pos)
        if key in seen:
            continue
        seen.add(key)

        entries.append(
            {
                "word": word,
                "pos": pos,
                "cefr": cefr,
                "in_ox_3000": in_ox_3000,
                "in_ox_5000": in_ox_5000,
                "audio_uk": audio_uk,
                "audio_us": audio_us,
            }
        )

    return entries


def upsert(entries: Iterable[dict]) -> tuple[int, int]:
    inserted = 0
    updated = 0
    with get_connection() as conn, conn.cursor() as cur:
        # Do not reorder existing rows; only control the order of future
        # inserts/upserts from the source feed.
        ordered_entries = sorted(
            entries,
            key=lambda entry: (
                str(entry.get("word", "")).lower(),
                str(entry.get("pos", "")).lower(),
            ),
        )
        for e in ordered_entries:
            cur.execute(
                """
                INSERT INTO vocabulary
                  (word, pos, cefr, in_oxford_3000, in_oxford_5000, audio_uk, audio_us)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (word, pos) DO UPDATE SET
                  cefr = EXCLUDED.cefr,
                  in_oxford_3000 = EXCLUDED.in_oxford_3000,
                  in_oxford_5000 = EXCLUDED.in_oxford_5000,
                  audio_uk = COALESCE(EXCLUDED.audio_uk, vocabulary.audio_uk),
                  audio_us = COALESCE(EXCLUDED.audio_us, vocabulary.audio_us)
                RETURNING (xmax = 0) AS was_insert;
                """,
                (
                    e["word"],
                    e["pos"],
                    e["cefr"],
                    e["in_ox_3000"],
                    e["in_ox_5000"],
                    e["audio_uk"],
                    e["audio_us"],
                ),
            )
            row = cur.fetchone()
            if row and row[0]:
                inserted += 1
            else:
                updated += 1
    return inserted, updated


def run() -> None:
    print(f"Fetching {URL} …")
    html = fetch_html()
    print(f"  downloaded {len(html):,} bytes")

    entries = parse_entries(html)
    print(f"  parsed {len(entries):,} entries")
    if not entries:
        print("  no entries parsed — page structure may have changed", file=sys.stderr)
        sys.exit(2)

    by_level: dict[str, int] = {}
    for e in entries:
        by_level[e["cefr"]] = by_level.get(e["cefr"], 0) + 1
    pretty = ", ".join(
        f"{lvl.upper()}={n}" for lvl, n in sorted(by_level.items())
    )
    print(f"  by level: {pretty}")

    inserted, updated = upsert(entries)
    print(f"  inserted {inserted:,}, updated {updated:,}")


if __name__ == "__main__":
    run()
