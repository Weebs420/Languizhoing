# Data Pipeline

Python jobs that keep the Bangla → American English translator app fresh.

## Jobs

- `expand_phrasebook.py` — uses Claude to add new idioms / slang / Gen Z phrases
  to the `phrasebook` table. Safe to re-run; uses ON CONFLICT to dedupe.
- `generate_vocabulary.py` — uses Claude to add at least 50 new English words
  with part-of-speech-aware Bangla meanings to the `vocabulary` table.
- `fetch_news.py` — pulls Bangla headlines from public RSS feeds
  (Prothom Alo, BDNews24, Banglanews24) and pre-translates them into the
  `news_items` table.
- `run_daily.py` — daily refresh that adds 50+ vocabulary translations, 50+
  phrasebook translations, and refreshes news.
- `run_all.py` — runs every job in order. Use this for scheduled refreshes.

New vocabulary is inserted alphabetically by word from this point forward.
Existing rows are deliberately left in their current order.

## Run locally

```bash
pip install -r requirements.txt
python run_all.py
```

Environment variables required (already set on Replit):

- `DATABASE_URL`
- `AI_INTEGRATIONS_ANTHROPIC_BASE_URL`
- `AI_INTEGRATIONS_ANTHROPIC_API_KEY`

## Schedule it

To make the app update on its own, create a Replit Scheduled Deployment with
this command and a daily schedule:

```bash
cd data-pipeline && uv run python run_daily.py
```

The daily job fails rather than silently accepting fewer than 50 new entries.
It is safe to retry because vocabulary is unique by word + part of speech and
phrasebook entries are unique by Bangla phrase.
