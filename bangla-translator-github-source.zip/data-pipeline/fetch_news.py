"""Fetch Bangla news headlines from public RSS feeds and pre-translate them.

Stores deduplicated entries in the `news_items` table. Safe to run repeatedly.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

import feedparser
from dateutil import parser as dateparser

from db import get_connection
from llm import complete_json

# Public Bangla news RSS feeds.
FEEDS = [
    "https://www.prothomalo.com/feed",
    "https://bangla.bdnews24.com/?widgetName=rssfeed&widgetId=1150&getXmlFeed=true",
    "https://www.banglanews24.com/rss/rss.xml",
]

MAX_ITEMS_PER_FEED = 8

SYSTEM = """You are a Bangla → American English news translator.

Translate the supplied Bangla headlines and short summaries into clear,
concise American English suitable for a news ticker. Keep proper nouns
intact. Be neutral and journalistic.

Return strict JSON: a list of objects, in the same order as the input,
each with:
- "title_en": English translation of the headline
- "summary_en": English translation of the summary (or empty string if no summary was provided)

No prose, no code fences."""


@dataclass
class RawItem:
    source_url: str
    title_bn: str
    summary_bn: str
    published_at: Optional[datetime]


def parse_published(entry) -> Optional[datetime]:
    raw = entry.get("published") or entry.get("updated")
    if not raw:
        return None
    try:
        dt = dateparser.parse(raw)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except (ValueError, TypeError):
        return None


def fetch_feeds() -> list[RawItem]:
    items: list[RawItem] = []
    for url in FEEDS:
        try:
            parsed = feedparser.parse(url)
        except Exception as exc:  # noqa: BLE001
            print(f"  ! failed to fetch {url}: {exc}", file=sys.stderr)
            continue

        for entry in parsed.entries[:MAX_ITEMS_PER_FEED]:
            link = entry.get("link") or ""
            title = (entry.get("title") or "").strip()
            summary = (entry.get("summary") or entry.get("description") or "").strip()
            # Strip HTML tags from summary roughly.
            summary = _strip_html(summary)[:400]
            if not link or not title:
                continue
            items.append(
                RawItem(
                    source_url=link,
                    title_bn=title,
                    summary_bn=summary,
                    published_at=parse_published(entry),
                )
            )
    return items


def _strip_html(text: str) -> str:
    import re

    text = re.sub(r"<[^>]+>", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def filter_new(cur, items: list[RawItem]) -> list[RawItem]:
    if not items:
        return []
    urls = [i.source_url for i in items]
    cur.execute(
        "SELECT source_url FROM news_items WHERE source_url = ANY(%s)", (urls,)
    )
    existing = {row[0] for row in cur.fetchall()}
    return [i for i in items if i.source_url not in existing]


def translate_batch(items: list[RawItem]) -> list[dict]:
    payload_lines = []
    for idx, item in enumerate(items, 1):
        payload_lines.append(
            f"{idx}. TITLE: {item.title_bn}\n   SUMMARY: {item.summary_bn or '(none)'}"
        )
    user = "Translate these Bangla news entries:\n\n" + "\n\n".join(payload_lines)
    result = complete_json(SYSTEM, user)
    if not isinstance(result, list):
        raise ValueError("Translator output was not a list")
    if len(result) != len(items):
        # Pad/truncate defensively.
        result = (result + [{}] * len(items))[: len(items)]
    return result


def insert_items(cur, items: list[RawItem], translations: list[dict]) -> int:
    inserted = 0
    for item, tr in zip(items, translations):
        title_en = (tr.get("title_en") or "").strip()
        summary_en = (tr.get("summary_en") or "").strip() or None
        if not title_en:
            continue
        cur.execute(
            """
            INSERT INTO news_items
              (source_url, title_bn, title_en, summary_bn, summary_en, published_at)
            VALUES (%s, %s, %s, %s, %s, %s)
            ON CONFLICT (source_url) DO NOTHING
            """,
            (
                item.source_url,
                item.title_bn,
                title_en,
                item.summary_bn or None,
                summary_en,
                item.published_at,
            ),
        )
        if cur.rowcount > 0:
            inserted += 1
    return inserted


def sync_id_sequence(cur) -> None:
    """Repair a sequence that may lag behind rows imported by older scripts."""
    cur.execute(
        """
        SELECT setval(
          pg_get_serial_sequence('news_items', 'id'),
          COALESCE((SELECT MAX(id) FROM news_items), 1),
          TRUE
        )
        """
    )


def run() -> int:
    raw = fetch_feeds()
    print(f"Fetched {len(raw)} raw entries from {len(FEEDS)} feeds.")
    if not raw:
        return 0

    with get_connection() as conn:
        cur = conn.cursor()
        sync_id_sequence(cur)
        new_items = filter_new(cur, raw)
        print(f"{len(new_items)} are new (after dedup).")
        if not new_items:
            return 0

        # Translate in chunks to keep prompt size reasonable.
        chunk_size = 8
        total = 0
        for i in range(0, len(new_items), chunk_size):
            chunk = new_items[i : i + chunk_size]
            translations = translate_batch(chunk)
            total += insert_items(cur, chunk, translations)
        print(f"Inserted {total} translated news items.")
        return total


if __name__ == "__main__":
    try:
        run()
    except Exception as exc:  # noqa: BLE001
        print(f"fetch_news failed: {exc}", file=sys.stderr)
        sys.exit(1)
