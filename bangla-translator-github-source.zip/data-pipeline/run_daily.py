"""Run the daily content refresh for the Bangla translator.

This is the command to use for a daily Scheduled Deployment:

    uv run python run_daily.py

Each successful run adds at least 50 new vocabulary words with Bangla
translations and at least 50 new phrasebook translations, then refreshes news.
Every job is idempotent and duplicate-safe.
"""

from __future__ import annotations

import sys

import expand_phrasebook
import fetch_news
import generate_vocabulary


def run() -> None:
    failures = 0

    print("== generate_vocabulary (50+) ==")
    try:
        added = generate_vocabulary.run(target=50)
        print(f"  added {added} vocabulary words with Bangla meanings")
    except Exception as exc:  # noqa: BLE001
        failures += 1
        print(f"generate_vocabulary failed: {exc}", file=sys.stderr)

    print("\n== expand_phrasebook (50+) ==")
    try:
        added = expand_phrasebook.run(batch_size=50)
        print(f"  added {added} phrasebook translations")
    except Exception as exc:  # noqa: BLE001
        failures += 1
        print(f"expand_phrasebook failed: {exc}", file=sys.stderr)

    print("\n== fetch_news ==")
    try:
        fetch_news.run()
    except Exception as exc:  # noqa: BLE001
        failures += 1
        print(f"fetch_news failed: {exc}", file=sys.stderr)

    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    run()