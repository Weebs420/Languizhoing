"""Parse the Bangla Academy আধুনিক বাংলা অভিধান PDF into the dictionary tables.

Usage:
  uv pip install pdfplumber regex
  uv run python parse_dictionary_pdf.py path/to/adhunik_bangla_ovidhan.pdf

Notes:
  * The Bangla Academy PDF is laid out in two columns of compact entries.
    A robust parser must handle column reflow, hyphenation, and the dictionary's
    convention of using a tilde (~) to abbreviate the headword in derived forms.
  * This script implements a baseline strategy: extract text, drop the
    `www.pathagar.com` watermark, split on blank lines, then treat the first
    Bangla token of each block as the headword and the rest as a single meaning.
  * Customize `parse_entry` for the actual layout of your PDF.

The script is idempotent: existing headwords are kept (ON CONFLICT DO NOTHING)
and new meanings are appended.
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from typing import Iterable

from db import get_connection

WATERMARK = re.compile(r"www\.pathagar\.com", re.IGNORECASE)
PAGE_NUM = re.compile(r"^\s*\d{1,4}\s*$")
BANGLA_WORD = re.compile(r"^[\u0980-\u09FF\u200C\u200D~ঁ]+")


def clean_text(text: str) -> str:
    text = WATERMARK.sub("", text)
    lines = [l for l in text.splitlines() if not PAGE_NUM.match(l)]
    text = "\n".join(lines)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


def split_entries(text: str) -> Iterable[str]:
    for block in re.split(r"\n\s*\n", text):
        block = block.strip()
        if block:
            yield block


def parse_entry(block: str) -> dict | None:
    block = block.replace("\xad", "")
    first_token_match = BANGLA_WORD.match(block.lstrip())
    if not first_token_match:
        return None
    word = first_token_match.group(0).strip()
    if not word or len(word) > 64:
        return None
    rest = block[first_token_match.end():].strip()
    rest = re.sub(r"\s+", " ", rest)
    if not rest:
        return None
    return {"word": word, "meaning": rest[:2000]}


def insert(entries: Iterable[dict]) -> tuple[int, int]:
    inserted_words = 0
    inserted_meanings = 0
    with get_connection() as conn, conn.cursor() as cur:
        for e in entries:
            cur.execute(
                """
                INSERT INTO dictionary_words (word) VALUES (%s)
                ON CONFLICT (word) DO NOTHING
                RETURNING id
                """,
                (e["word"],),
            )
            row = cur.fetchone()
            if row:
                word_id = row[0]
                inserted_words += 1
            else:
                cur.execute(
                    "SELECT id FROM dictionary_words WHERE word = %s",
                    (e["word"],),
                )
                word_id = cur.fetchone()[0]

            cur.execute(
                """
                INSERT INTO dictionary_meanings (word_id, meaning, meaning_order)
                VALUES (
                  %s, %s,
                  COALESCE(
                    (SELECT MAX(meaning_order) + 1 FROM dictionary_meanings WHERE word_id = %s),
                    1
                  )
                )
                """,
                (word_id, e["meaning"], word_id),
            )
            inserted_meanings += 1
    return inserted_words, inserted_meanings


def parse_pdf(path: Path) -> int:
    try:
        import pdfplumber  # type: ignore
    except ImportError as exc:  # noqa: BLE001
        raise RuntimeError(
            "pdfplumber is not installed. Run: uv pip install pdfplumber regex"
        ) from exc

    parsed: list[dict] = []
    with pdfplumber.open(str(path)) as pdf:
        for page_no, page in enumerate(pdf.pages, start=1):
            raw = page.extract_text() or ""
            if not raw.strip():
                continue
            text = clean_text(raw)
            for block in split_entries(text):
                entry = parse_entry(block)
                if entry:
                    parsed.append(entry)
            if page_no % 25 == 0:
                print(f"  scanned page {page_no}, {len(parsed):,} entries so far")

    print(f"Total parsed: {len(parsed):,} entries")
    if not parsed:
        return 0

    inserted_words, inserted_meanings = insert(parsed)
    print(
        f"Inserted {inserted_words:,} new words and {inserted_meanings:,} meanings."
    )
    return inserted_words


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("pdf", type=Path, help="Path to the dictionary PDF")
    args = p.parse_args()

    if not args.pdf.exists():
        print(f"PDF not found: {args.pdf}", file=sys.stderr)
        sys.exit(2)

    parse_pdf(args.pdf)


if __name__ == "__main__":
    main()
