"""Seed the Bangla dictionary with authentic Bangla Academy-style entries.

Inspired by বাংলা একাডেমি আধুনিক বাংলা অভিধান. Each entry has:
  - Bangla headword
  - phonetic pronunciation in IPA-ish Bangla
  - part of speech (in Bangla — বিশেষ্য, ক্রিয়া, …)
  - origin (Sanskrit, Persian, Arabic, English, Portuguese, …)
  - one or more numbered meanings
  - example sentence(s) in Bangla
  - synonyms / antonyms

Idempotent: skips any headword that already exists.

Run:
  uv run python seed_dictionary.py [--count 30]
"""

from __future__ import annotations

import argparse
import sys

from db import get_connection
from llm import complete_json

SYSTEM = """You are a Bengali lexicographer trained on বাংলা একাডেমি আধুনিক
বাংলা অভিধান. You write authoritative dictionary entries in Bangla.

Output strictly valid JSON: a list of objects with these exact fields:
- "word": the Bangla headword (Bangla script, no diacritic numerals)
- "pronunciation": phonetic pronunciation in Bangla script with brackets,
  e.g. "[বই]" or "[ভালোবাসা]"
- "part_of_speech": Bangla part of speech such as "বিশেষ্য", "ক্রিয়া",
  "বিশেষণ", "ক্রিয়াবিশেষণ", "সর্বনাম", "অব্যয়"
- "origin": brief etymology in Bangla, e.g. "সংস্কৃত", "ফারসি", "আরবি",
  "ইংরেজি", "পর্তুগিজ", or "তদ্ভব ← সংস্কৃত"
- "meanings": list of 1–3 short, formal meanings in Bangla
- "examples": list of 1–2 example sentences in Bangla using the headword
- "synonyms": list of 0–4 Bangla synonyms
- "antonyms": list of 0–3 Bangla antonyms (use [] if none apply)

Cover everyday Bangla vocabulary an adult Bengali speaker uses. No prose,
no markdown, no code fences — JSON only."""

USER_TEMPLATE = """Generate {count} Bangla dictionary entries that are NOT in
this existing list:

{existing}

Pick common, useful headwords across nouns, verbs, adjectives, and adverbs.
Mix Tatsama, Tadbhava, and loanwords from Persian/Arabic/English. Avoid
proper nouns and offensive terms."""


def fetch_existing(cur, limit: int = 500) -> list[str]:
    cur.execute(
        "SELECT word FROM dictionary_words ORDER BY id DESC LIMIT %s",
        (limit,),
    )
    return [row[0] for row in cur.fetchall()]


def insert_entry(cur, entry: dict) -> bool:
    word = (entry.get("word") or "").strip()
    if not word:
        return False

    cur.execute(
        """
        INSERT INTO dictionary_words (word, pronunciation, part_of_speech, origin)
        VALUES (%s, %s, %s, %s)
        ON CONFLICT (word) DO NOTHING
        RETURNING id
        """,
        (
            word,
            (entry.get("pronunciation") or "").strip()[:255] or None,
            (entry.get("part_of_speech") or "").strip()[:100] or None,
            (entry.get("origin") or "").strip() or None,
        ),
    )
    row = cur.fetchone()
    if not row:
        return False
    word_id = row[0]

    meanings = entry.get("meanings") or []
    if isinstance(meanings, str):
        meanings = [meanings]
    for order, m in enumerate(meanings, start=1):
        text = (m or "").strip() if isinstance(m, str) else ""
        if not text:
            continue
        cur.execute(
            "INSERT INTO dictionary_meanings (word_id, meaning, meaning_order) VALUES (%s, %s, %s)",
            (word_id, text, order),
        )

    for ex in entry.get("examples") or []:
        text = (ex or "").strip() if isinstance(ex, str) else ""
        if text:
            cur.execute(
                "INSERT INTO dictionary_examples (word_id, example) VALUES (%s, %s)",
                (word_id, text),
            )

    for syn in entry.get("synonyms") or []:
        text = (syn or "").strip()[:255] if isinstance(syn, str) else ""
        if text:
            cur.execute(
                "INSERT INTO dictionary_synonyms (word_id, synonym) VALUES (%s, %s)",
                (word_id, text),
            )

    for ant in entry.get("antonyms") or []:
        text = (ant or "").strip()[:255] if isinstance(ant, str) else ""
        if text:
            cur.execute(
                "INSERT INTO dictionary_antonyms (word_id, antonym) VALUES (%s, %s)",
                (word_id, text),
            )

    return True


def run(batch_size: int = 30) -> int:
    with get_connection() as conn:
        cur = conn.cursor()
        existing = fetch_existing(cur)
        existing_text = "\n".join(f"- {w}" for w in existing) or "(empty)"

        prompt = USER_TEMPLATE.format(count=batch_size, existing=existing_text)
        result = complete_json(SYSTEM, prompt, max_tokens=8192)

        entries = result if isinstance(result, list) else result.get("entries", [])
        if not isinstance(entries, list):
            raise ValueError("Model output was not a list")

        inserted = 0
        for entry in entries:
            if insert_entry(cur, entry):
                inserted += 1
        print(f"Inserted {inserted} new dictionary entries (requested {batch_size}).")
        return inserted


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--count", type=int, default=30)
    args = p.parse_args()
    try:
        run(args.count)
    except Exception as exc:  # noqa: BLE001
        print(f"seed_dictionary failed: {exc}", file=sys.stderr)
        sys.exit(1)
