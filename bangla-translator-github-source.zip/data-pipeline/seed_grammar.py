"""Seed the Bangla grammar reference with the standard structure of
বাংলা ব্যাকরণ (Bangla Vyakaran) starting with Chapter 1 verbatim from the
user-provided dataset, then extending to subsequent chapters.

Idempotent: rows are keyed by (chapter ordinal, section ordinal,
topic ordinal) and only inserted if the title doesn't already exist for
that parent.
"""

from __future__ import annotations

import sys

from db import get_connection

# Each chapter: (ordinal, title, description, sections)
# Each section : (ordinal, title, topics)
# Each topic   : (ordinal, title, content, [(rule), …], [(example, explanation), …])
CHAPTERS: list[dict] = [
    {
        "ordinal": 1,
        "title": "প্রথম অধ্যায়",
        "description": "ভাষা ও ব্যাকরণ",
        "sections": [
            {
                "ordinal": 1,
                "title": "ভাষা বা বাংলা ভাষা",
                "topics": [
                    {
                        "ordinal": 1,
                        "title": "ভাষার সংজ্ঞা",
                        "content": (
                            "মানুষ যে ধ্বনির মাধ্যমে মনের ভাব প্রকাশ করে "
                            "তার নাম ভাষা।"
                        ),
                        "rules": [
                            "ভাষা মানুষের সৃষ্টি — পশুপাখির ডাক ভাষা নয়।",
                            "ভাষার মূল উপাদান ধ্বনি; ধ্বনি থেকে শব্দ ও বাক্য গঠিত হয়।",
                        ],
                        "examples": [
                            (
                                "‘আমি ভাত খাই’ — এটি একটি বাক্য, যা বাংলা ভাষার "
                                "নিয়ম মেনে গঠিত।",
                                "ধ্বনি → শব্দ → বাক্য — এই ক্রমে ভাষা গঠিত হয়।",
                            )
                        ],
                    },
                ],
            },
            {
                "ordinal": 2,
                "title": "ব্যাকরণ",
                "topics": [
                    {
                        "ordinal": 1,
                        "title": "ব্যাকরণের সংজ্ঞা",
                        "content": (
                            "যে বিদ্যার দ্বারা ভাষার গঠন বিশ্লেষণ করা হয় "
                            "তাকে ব্যাকরণ বলে।"
                        ),
                        "rules": [
                            "ব্যাকরণ ভাষার নিয়ম শেখায়, ভাষাকে শুদ্ধভাবে ব্যবহার করতে সাহায্য করে।",
                        ],
                        "examples": [
                            (
                                "‘সে স্কুলে যাচ্ছে’ — কর্তা, কর্ম ও ক্রিয়া "
                                "যথাযথ স্থানে বসেছে।",
                                "ব্যাকরণ এই বাক্যের গঠন ব্যাখ্যা করে।",
                            )
                        ],
                    },
                    {
                        "ordinal": 2,
                        "title": "ব্যাকরণ আলোচ্য বিষয়",
                        "content": (
                            "ব্যাকরণে প্রধানত চারটি বিষয় আলোচিত হয় — "
                            "ধ্বনিতত্ত্ব, রূপতত্ত্ব, বাক্যতত্ত্ব ও অর্থতত্ত্ব।"
                        ),
                        "rules": [
                            "ধ্বনিতত্ত্ব: ধ্বনির উচ্চারণ, পরিবর্তন ও সংযোগ।",
                            "রূপতত্ত্ব: শব্দ গঠন, প্রকৃতি, প্রত্যয়, সমাস।",
                            "বাক্যতত্ত্ব: বাক্যের গঠন ও পদক্রম।",
                            "অর্থতত্ত্ব: শব্দের অর্থ ও প্রয়োগ।",
                        ],
                        "examples": [],
                    },
                ],
            },
        ],
    },
    {
        "ordinal": 2,
        "title": "দ্বিতীয় অধ্যায়",
        "description": "ধ্বনিতত্ত্ব",
        "sections": [
            {
                "ordinal": 1,
                "title": "ধ্বনি ও বর্ণ",
                "topics": [
                    {
                        "ordinal": 1,
                        "title": "ধ্বনির সংজ্ঞা",
                        "content": (
                            "মানুষের বাগ্‌যন্ত্র দ্বারা উচ্চারিত ক্ষুদ্রতম "
                            "শব্দাংশকে ধ্বনি বলে।"
                        ),
                        "rules": [
                            "বাংলায় মূল ধ্বনি দুই প্রকার — স্বরধ্বনি ও ব্যঞ্জনধ্বনি।",
                            "স্বরধ্বনির সংখ্যা ৭টি, ব্যঞ্জনধ্বনির সংখ্যা ২৯টি।",
                        ],
                        "examples": [
                            ("ক্, খ্, গ্ — ব্যঞ্জনধ্বনির উদাহরণ।", None),
                            ("অ, আ, ই — স্বরধ্বনির উদাহরণ।", None),
                        ],
                    },
                    {
                        "ordinal": 2,
                        "title": "বর্ণের সংজ্ঞা",
                        "content": (
                            "ধ্বনি প্রকাশের লিখিত প্রতীকই বর্ণ। "
                            "বাংলা বর্ণমালায় ৫০টি বর্ণ আছে — ১১টি স্বরবর্ণ ও ৩৯টি ব্যঞ্জনবর্ণ।"
                        ),
                        "rules": [
                            "প্রতিটি ধ্বনির জন্য আলাদা বর্ণ আছে — তবে কিছু ধ্বনি একাধিক বর্ণে প্রকাশিত হয়।",
                        ],
                        "examples": [],
                    },
                ],
            },
        ],
    },
    {
        "ordinal": 3,
        "title": "তৃতীয় অধ্যায়",
        "description": "শব্দ ও পদ",
        "sections": [
            {
                "ordinal": 1,
                "title": "শব্দ",
                "topics": [
                    {
                        "ordinal": 1,
                        "title": "শব্দের সংজ্ঞা ও প্রকারভেদ",
                        "content": (
                            "এক বা একাধিক ধ্বনির অর্থপূর্ণ সমষ্টিকে শব্দ বলে। "
                            "উৎপত্তি অনুসারে শব্দ পাঁচ প্রকার — তৎসম, অর্ধতৎসম, "
                            "তদ্ভব, দেশি ও বিদেশি।"
                        ),
                        "rules": [
                            "তৎসম: সংস্কৃত থেকে অপরিবর্তিত শব্দ — চন্দ্র, সূর্য।",
                            "তদ্ভব: সংস্কৃত থেকে রূপান্তরিত শব্দ — হাত (← হস্ত)।",
                            "দেশি: আদিবাসী ভাষা থেকে — কুলা, ঢেঁকি।",
                            "বিদেশি: ফারসি, আরবি, ইংরেজি প্রভৃতি — কলম, চেয়ার, স্কুল।",
                        ],
                        "examples": [
                            ("‘বই’ — তদ্ভব শব্দ।", "সংস্কৃত ‘বহি’ থেকে এসেছে।"),
                        ],
                    },
                ],
            },
            {
                "ordinal": 2,
                "title": "পদ",
                "topics": [
                    {
                        "ordinal": 1,
                        "title": "পদের সংজ্ঞা ও প্রকারভেদ",
                        "content": (
                            "বাক্যে ব্যবহৃত প্রতিটি শব্দকে পদ বলে। "
                            "পদ পাঁচ প্রকার — বিশেষ্য, সর্বনাম, বিশেষণ, "
                            "ক্রিয়া ও অব্যয়।"
                        ),
                        "rules": [
                            "বিশেষ্য: কোনো ব্যক্তি, বস্তু বা স্থানের নাম — রহিম, ঢাকা।",
                            "সর্বনাম: বিশেষ্যের পরিবর্তে ব্যবহৃত পদ — সে, আমি।",
                            "বিশেষণ: বিশেষ্য বা সর্বনামের গুণ বোঝায় — ভালো, লাল।",
                            "ক্রিয়া: কাজ বোঝায় — খাই, যাই।",
                            "অব্যয়: যে পদের রূপ পরিবর্তন হয় না — এবং, কিন্তু।",
                        ],
                        "examples": [
                            (
                                "‘রহিম ভালো ছেলে’ — রহিম (বিশেষ্য), ভালো (বিশেষণ), ছেলে (বিশেষ্য)।",
                                None,
                            ),
                        ],
                    },
                ],
            },
        ],
    },
]


def upsert_chapter(cur, ch: dict) -> int:
    cur.execute(
        """
        SELECT id FROM grammar_chapters WHERE ordinal = %s LIMIT 1
        """,
        (ch["ordinal"],),
    )
    row = cur.fetchone()
    if row:
        return row[0]
    cur.execute(
        """
        INSERT INTO grammar_chapters (title, description, ordinal)
        VALUES (%s, %s, %s) RETURNING id
        """,
        (ch["title"], ch.get("description"), ch["ordinal"]),
    )
    return cur.fetchone()[0]


def upsert_section(cur, chapter_id: int, sec: dict) -> int:
    cur.execute(
        "SELECT id FROM grammar_sections WHERE chapter_id = %s AND ordinal = %s LIMIT 1",
        (chapter_id, sec["ordinal"]),
    )
    row = cur.fetchone()
    if row:
        return row[0]
    cur.execute(
        """
        INSERT INTO grammar_sections (chapter_id, title, ordinal)
        VALUES (%s, %s, %s) RETURNING id
        """,
        (chapter_id, sec["title"], sec["ordinal"]),
    )
    return cur.fetchone()[0]


def upsert_topic(cur, section_id: int, top: dict) -> tuple[int, bool]:
    cur.execute(
        "SELECT id FROM grammar_topics WHERE section_id = %s AND ordinal = %s LIMIT 1",
        (section_id, top["ordinal"]),
    )
    row = cur.fetchone()
    if row:
        return row[0], False
    cur.execute(
        """
        INSERT INTO grammar_topics (section_id, title, content, ordinal)
        VALUES (%s, %s, %s, %s) RETURNING id
        """,
        (section_id, top["title"], top["content"], top["ordinal"]),
    )
    return cur.fetchone()[0], True


def insert_rule(cur, topic_id: int, text: str) -> bool:
    cur.execute(
        "SELECT 1 FROM grammar_rules WHERE topic_id = %s AND rule_text = %s LIMIT 1",
        (topic_id, text),
    )
    if cur.fetchone():
        return False
    cur.execute(
        "INSERT INTO grammar_rules (topic_id, rule_text) VALUES (%s, %s)",
        (topic_id, text),
    )
    return True


def insert_example(cur, topic_id: int, text: str, explanation: str | None) -> bool:
    cur.execute(
        "SELECT 1 FROM grammar_examples WHERE topic_id = %s AND example_text = %s LIMIT 1",
        (topic_id, text),
    )
    if cur.fetchone():
        return False
    cur.execute(
        "INSERT INTO grammar_examples (topic_id, example_text, explanation) VALUES (%s, %s, %s)",
        (topic_id, text, explanation),
    )
    return True


def run() -> None:
    chapters = sections = topics = rules = examples = 0
    with get_connection() as conn, conn.cursor() as cur:
        for ch in CHAPTERS:
            ch_id = upsert_chapter(cur, ch)
            chapters += 1
            for sec in ch["sections"]:
                sec_id = upsert_section(cur, ch_id, sec)
                sections += 1
                for top in sec["topics"]:
                    top_id, inserted = upsert_topic(cur, sec_id, top)
                    if inserted:
                        topics += 1
                    for rule_text in top.get("rules", []):
                        if insert_rule(cur, top_id, rule_text):
                            rules += 1
                    for ex in top.get("examples", []):
                        if isinstance(ex, tuple):
                            text, explanation = ex
                        else:
                            text, explanation = ex, None
                        if insert_example(cur, top_id, text, explanation):
                            examples += 1
    print(
        f"Grammar seed: chapters={chapters}, sections={sections}, "
        f"topics={topics} new, rules={rules} new, examples={examples} new"
    )


if __name__ == "__main__":
    try:
        run()
    except Exception as exc:  # noqa: BLE001
        print(f"seed_grammar failed: {exc}", file=sys.stderr)
        sys.exit(1)
