# GitHub Transfer Guide

This repository contains the Bangla → American English translator application,
its shared API, Expo mobile client, database schemas, AI translation logic,
daily content pipeline, and polyglot companion tools.

## Included application areas

- `artifacts/api-server/` — Express API server
- `artifacts/bangla-translator/` — Expo mobile application
- `lib/api-spec/` — OpenAPI source contract
- `lib/api-client-react/` — generated React Query client
- `lib/api-zod/` — generated Zod schemas
- `lib/db/` — Drizzle PostgreSQL schema
- `data-pipeline/` — daily vocabulary, phrasebook, news, and translation jobs
- `polyglot/` — C, C++, JavaScript, Python, Go, Java, Julia, R, Swift, Kotlin,
  Dart/Flutter companion programs
- `scripts/` — workspace utility scripts

## Requirements

- Node.js 24
- pnpm 10+
- Python 3.11+
- `uv`
- PostgreSQL

## Install

```bash
pnpm install
uv sync
```

## Environment variables

Configure these through your deployment provider's secret manager. Never commit
their values to GitHub.

```text
DATABASE_URL
AI_INTEGRATIONS_ANTHROPIC_BASE_URL
AI_INTEGRATIONS_ANTHROPIC_API_KEY
SESSION_SECRET
```

The AI integration variables use Replit's Anthropic proxy in the original
environment. Outside Replit, replace them with the compatible Anthropic API
base URL and API key provided by your hosting setup.

## Run the API

```bash
pnpm --filter @workspace/api-server run dev
```

## Run the mobile app

```bash
pnpm --filter @workspace/bangla-translator run dev
```

## Database

After setting `DATABASE_URL`, apply the Drizzle schema in the development
database:

```bash
pnpm --filter @workspace/db run push
```

## API client generation

When `lib/api-spec/openapi.yaml` changes, regenerate the shared clients:

```bash
pnpm --filter @workspace/api-spec run codegen
```

## Daily content refresh

The daily job adds at least 50 new vocabulary words with Bangla meanings,
at least 50 phrasebook translations, and refreshes news:

```bash
cd data-pipeline
uv run python run_daily.py
```

The vocabulary job preserves the current database order and inserts future
vocabulary alphabetically by word. It uses database uniqueness constraints to
avoid duplicate entries.

## Validation

```bash
pnpm run typecheck:libs
pnpm --filter @workspace/api-server run typecheck
pnpm --filter @workspace/bangla-translator run typecheck
```