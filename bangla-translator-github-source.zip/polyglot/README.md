# Polyglot Toolkit

Companion programs for the Bangla → American English translator app, written
in many languages. Each one does something real for the same database and
translation API — no toy code.

| Folder | Language | What it does |
|---|---|---|
| `bash/` | Bash | DB backup, scheduled refresh, deploy prep |
| `c/bangla-normalizer/` | C | Single-pass UTF-8 normalizer + syllable counter for Bangla text |
| `cpp/vocab-trie/` | C++ | Trie + Levenshtein daemon for Oxford-vocab prefix and "did you mean…?" search |
| `javascript/phrasebook-cheatsheet/` | JavaScript (Node) | Zero-dep CLI that turns the phrasebook into a printable HTML cheat sheet |
| `python/cli-translate/` | Python | Standard-library CLI client for `/translate` |
| `go/translation-cache/` | Go | High-performance HTTP translation cache proxy |
| `java/analytics-cli/` | Java | Reads the `translations` table and prints usage stats |
| `julia/usage-report/` | Julia | Time-series usage report from the database |
| `r/quality-report/` | R | Translation length & tone analysis report (writes a Markdown file) |
| `swift/cli-translate/` | Swift | iOS-style CLI client that calls `/translate` |
| `kotlin/cli-translate/` | Kotlin | Android-style CLI client that calls `/translate` |
| `flutter/translator_lite/` | Dart / Flutter | Second mobile client (Flutter app skeleton) |

The heavyweight Python data pipeline (phrasebook expander, news fetcher) lives
in the top-level [`data-pipeline/`](../data-pipeline) folder.

Each subfolder has its own README with install / run instructions. They all
read the same `DATABASE_URL` and (where relevant) hit the same Express API on
`$REPLIT_DEV_DOMAIN`.
