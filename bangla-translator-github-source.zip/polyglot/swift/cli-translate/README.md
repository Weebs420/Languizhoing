# cli-translate (Swift)

Swift CLI that calls `POST /api/translate`. Same shape as the Python and
Kotlin clients — useful as a starting point for an iOS networking layer.

## Run

```bash
cd polyglot/swift/cli-translate
swift translate.swift "ভাই, আজকে অনেক প্যারা গেছে।" casual
```

Or compile to a binary:

```bash
swiftc translate.swift -o translate
./translate "তুমি কাল আসবা?" neutral
```

Reads `API_BASE_URL` (or falls back to `https://$REPLIT_DEV_DOMAIN`).
