// Swift CLI client for the bangla-translator API.
//
// Run:
//   swift translate.swift "ভাই, কেমন আছিস?" casual
//
// Or compile:
//   swiftc translate.swift -o translate
//   ./translate "তুমি কাল আসবা?" neutral

import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

struct TranslateResponse: Decodable {
    let translation: String
    let literal: String
    let notes: [String]
}

func baseURL() -> String {
    if let u = ProcessInfo.processInfo.environment["API_BASE_URL"], !u.isEmpty {
        return u.trimmingCharacters(in: ["/"])
    }
    if let d = ProcessInfo.processInfo.environment["REPLIT_DEV_DOMAIN"], !d.isEmpty {
        return "https://\(d)"
    }
    return "http://localhost:8080"
}

func translate(text: String, tone: String) throws -> TranslateResponse {
    guard let url = URL(string: "\(baseURL())/api/translate") else {
        throw NSError(domain: "url", code: 1)
    }
    var req = URLRequest(url: url)
    req.httpMethod = "POST"
    req.setValue("application/json", forHTTPHeaderField: "Content-Type")
    req.httpBody = try JSONSerialization.data(
        withJSONObject: ["text": text, "tone": tone]
    )

    let sema = DispatchSemaphore(value: 0)
    var result: Result<Data, Error>!
    URLSession.shared.dataTask(with: req) { data, _, err in
        if let err = err { result = .failure(err) }
        else if let data = data { result = .success(data) }
        else { result = .failure(NSError(domain: "empty", code: 0)) }
        sema.signal()
    }.resume()
    sema.wait()

    let data = try result.get()
    return try JSONDecoder().decode(TranslateResponse.self, from: data)
}

let args = CommandLine.arguments
let text = args.count > 1 ? args[1] : ""
let tone = args.count > 2 ? args[2] : "neutral"

guard !text.isEmpty else {
    FileHandle.standardError.write(Data(
        "Usage: translate <bangla text> [casual|neutral|formal]\n".utf8
    ))
    exit(1)
}

do {
    let r = try translate(text: text, tone: tone)
    print("")
    print("  Bangla : \(text)")
    print("  Tone   : \(tone)")
    print("")
    print("  English: \(r.translation)")
    print("  Literal: \(r.literal)")
    if !r.notes.isEmpty {
        print("  Notes  :")
        for n in r.notes { print("    • \(n)") }
    }
    print("")
} catch {
    FileHandle.standardError.write(Data("Error: \(error)\n".utf8))
    exit(2)
}
