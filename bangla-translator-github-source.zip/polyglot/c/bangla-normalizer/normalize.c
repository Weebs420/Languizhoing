/*
 * bangla-normalizer
 * -----------------
 * Reads UTF-8 Bangla text on stdin and writes JSON to stdout with:
 *   { "normalized": "...", "graphemes": N, "syllables": N, "bytes": N }
 *
 * Why C: the data pipeline calls this on every dictionary entry before
 * inserting it into Postgres, so it has to be cheap. A single-pass scanner
 * over a UTF-8 byte stream beats anything we can do in Python or Node.
 *
 * What it does:
 *   1. Strips Byte Order Mark (U+FEFF) and zero-width joiners that creep in
 *      from copy/paste.
 *   2. Collapses runs of whitespace into a single ASCII space.
 *   3. Counts Bangla syllables: every Bangla consonant (U+0995..U+09B9,
 *      U+09DC..U+09DF) that is NOT preceded by a hosonto (U+09CD)
 *      starts a new syllable.
 *
 * Build:  gcc -O2 -o normalize normalize.c
 * Use:    echo "আমি ভালো আছি" | ./normalize
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <ctype.h>

static int decode_utf8(const unsigned char *s, size_t n, uint32_t *cp, int *len) {
    if (n == 0) return 0;
    unsigned char c = s[0];
    if (c < 0x80) { *cp = c; *len = 1; return 1; }
    if ((c & 0xE0) == 0xC0 && n >= 2) {
        *cp = ((c & 0x1F) << 6) | (s[1] & 0x3F);
        *len = 2; return 1;
    }
    if ((c & 0xF0) == 0xE0 && n >= 3) {
        *cp = ((c & 0x0F) << 12) | ((s[1] & 0x3F) << 6) | (s[2] & 0x3F);
        *len = 3; return 1;
    }
    if ((c & 0xF8) == 0xF0 && n >= 4) {
        *cp = ((c & 0x07) << 18) | ((s[1] & 0x3F) << 12)
            | ((s[2] & 0x3F) << 6) | (s[3] & 0x3F);
        *len = 4; return 1;
    }
    return 0;
}

static void encode_utf8(uint32_t cp, char *out, int *len) {
    if (cp < 0x80) { out[0] = cp; *len = 1; return; }
    if (cp < 0x800) {
        out[0] = 0xC0 | (cp >> 6);
        out[1] = 0x80 | (cp & 0x3F);
        *len = 2; return;
    }
    if (cp < 0x10000) {
        out[0] = 0xE0 | (cp >> 12);
        out[1] = 0x80 | ((cp >> 6) & 0x3F);
        out[2] = 0x80 | (cp & 0x3F);
        *len = 3; return;
    }
    out[0] = 0xF0 | (cp >> 18);
    out[1] = 0x80 | ((cp >> 12) & 0x3F);
    out[2] = 0x80 | ((cp >> 6) & 0x3F);
    out[3] = 0x80 | (cp & 0x3F);
    *len = 4;
}

static int is_bangla_consonant(uint32_t cp) {
    return (cp >= 0x0995 && cp <= 0x09B9) || (cp >= 0x09DC && cp <= 0x09DF);
}

#define HOSONTO 0x09CD
#define ZWNJ    0x200C
#define ZWJ     0x200D
#define BOM     0xFEFF

static int is_ws(uint32_t cp) {
    return cp == ' ' || cp == '\t' || cp == '\n' || cp == '\r' || cp == 0x00A0;
}

int main(void) {
    size_t cap = 4096, len = 0;
    char *buf = malloc(cap);
    if (!buf) return 1;
    int ch;
    while ((ch = getchar()) != EOF) {
        if (len + 1 >= cap) { cap *= 2; buf = realloc(buf, cap); if (!buf) return 1; }
        buf[len++] = (char)ch;
    }

    char *out = malloc(len * 2 + 1);
    if (!out) return 1;
    size_t out_len = 0;
    size_t graphemes = 0, syllables = 0;
    uint32_t prev = 0;
    int prev_was_space = 1;

    size_t i = 0;
    while (i < len) {
        uint32_t cp; int clen;
        if (!decode_utf8((unsigned char *)buf + i, len - i, &cp, &clen)) {
            i++; continue;
        }
        i += clen;

        if (cp == BOM || cp == ZWNJ || cp == ZWJ) continue;

        if (is_ws(cp)) {
            if (!prev_was_space) {
                out[out_len++] = ' ';
                prev_was_space = 1;
            }
            prev = ' ';
            continue;
        }
        prev_was_space = 0;
        graphemes++;

        if (is_bangla_consonant(cp) && prev != HOSONTO) {
            syllables++;
        }

        char tmp[4]; int tlen;
        encode_utf8(cp, tmp, &tlen);
        memcpy(out + out_len, tmp, tlen);
        out_len += tlen;
        prev = cp;
    }

    while (out_len > 0 && out[out_len - 1] == ' ') out_len--;
    out[out_len] = 0;

    fputs("{\"normalized\":\"", stdout);
    for (size_t j = 0; j < out_len; j++) {
        unsigned char b = out[j];
        if (b == '"' || b == '\\') { putchar('\\'); putchar(b); }
        else if (b == '\n') fputs("\\n", stdout);
        else putchar(b);
    }
    printf("\",\"graphemes\":%zu,\"syllables\":%zu,\"bytes\":%zu}\n",
           graphemes, syllables, out_len);

    free(buf); free(out);
    return 0;
}
