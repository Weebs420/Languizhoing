# bangla-normalizer (C)

Single-pass UTF-8 scanner that cleans Bangla text and counts syllables.

The data pipeline calls this on every dictionary entry before insert so the
Postgres rows are stable (no stray BOMs / zero-width joiners) and so the
phrasebook UI can show a "syllable count" badge without re-parsing on the
client.

## Build & run

```bash
cd polyglot/c/bangla-normalizer
gcc -O2 -o normalize normalize.c
echo "আমি ভালো আছি" | ./normalize
# -> {"normalized":"আমি ভালো আছি","graphemes":11,"syllables":5,"bytes":31}
```

## What the rules cost you

Syllable counting is a *first approximation*: every Bangla consonant in
U+0995..U+09B9 (or U+09DC..U+09DF) that is not preceded by a hosonto
(U+09CD, the conjunct marker) starts a new syllable. That matches everyday
words but undercounts loanwords with stacked conjuncts. Good enough for a
"this is a 3-syllable phrase" badge; not good enough for poetry.
