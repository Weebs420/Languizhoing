# cli-translate (Python)

Standard-library Python CLI that calls `POST /api/translate`.

## Run

```bash
cd polyglot/python/cli-translate
python translate.py --text "ভাই, আজকে অনেক প্যারা গেছে।" --tone casual

# or pipe stdin
echo "তুমি কাল আসবা?" | python translate.py --tone neutral
```

Reads `API_BASE_URL` (or falls back to `https://$REPLIT_DEV_DOMAIN`, then
`http://localhost:8080`).
