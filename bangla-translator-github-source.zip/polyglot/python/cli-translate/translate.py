"""Python CLI client for the bangla-translator API.

Reads Bangla text (from --text or stdin), POSTs to /api/translate, and
prints the natural English translation, the literal version, and notes.

Run:
  python translate.py --text "ভাই, কেমন আছিস?" --tone casual
  echo "তুমি কাল আসবা?" | python translate.py --tone neutral
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.request


def base_url() -> str:
    if url := os.environ.get("API_BASE_URL"):
        return url.rstrip("/")
    if domain := os.environ.get("REPLIT_DEV_DOMAIN"):
        return f"https://{domain}"
    return "http://localhost:8080"


def translate(text: str, tone: str) -> dict:
    payload = json.dumps({"text": text, "tone": tone}).encode("utf-8")
    req = urllib.request.Request(
        url=f"{base_url()}/api/translate",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        return json.loads(resp.read().decode("utf-8"))


def main() -> int:
    p = argparse.ArgumentParser(description="Translate Bangla → American English")
    p.add_argument("--text", help="Bangla text (or read from stdin if omitted)")
    p.add_argument(
        "--tone",
        default="neutral",
        choices=["casual", "neutral", "formal"],
    )
    p.add_argument("--json", action="store_true", help="Print raw JSON only")
    args = p.parse_args()

    text = args.text or sys.stdin.read()
    text = text.strip()
    if not text:
        print("No input text provided.", file=sys.stderr)
        return 1

    try:
        result = translate(text, args.tone)
    except Exception as exc:  # noqa: BLE001
        print(f"Translation failed: {exc}", file=sys.stderr)
        return 2

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0

    print()
    print(f"  Bangla : {text}")
    print(f"  Tone   : {args.tone}")
    print()
    print(f"  English: {result['translation']}")
    print(f"  Literal: {result['literal']}")
    notes = result.get("notes") or []
    if notes:
        print("  Notes  :")
        for n in notes:
            print(f"    • {n}")
    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
