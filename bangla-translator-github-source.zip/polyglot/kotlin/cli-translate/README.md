# cli-translate (Kotlin)

Kotlin script that calls `POST /api/translate`. Uses only the JDK (no
external dependencies) so it can run wherever Kotlin + Java are available.

## Install Kotlin

Kotlin isn't a Replit module — install via SDKMAN!:

```bash
curl -s https://get.sdkman.io | bash
sdk install kotlin
```

(Java is already installed via `java-graalvm22.3` if you ran the polyglot
setup.)

## Run

```bash
cd polyglot/kotlin/cli-translate
kotlinc -script translate.main.kts -- "ভাই, কেমন আছিস?" casual
```

Reads `API_BASE_URL` (or falls back to `https://$REPLIT_DEV_DOMAIN`).
