#!/usr/bin/env kotlin
// Kotlin CLI client for the bangla-translator API.
//
// Run with kscript / kotlinc:
//   kotlinc -script translate.main.kts -- "ভাই, কেমন আছিস?" casual
//
// Same response shape as the Python / Swift clients — handy as a starting
// point for an Android networking layer.

import java.net.HttpURLConnection
import java.net.URI

fun baseUrl(): String {
    System.getenv("API_BASE_URL")?.takeIf { it.isNotBlank() }?.let {
        return it.trimEnd('/')
    }
    System.getenv("REPLIT_DEV_DOMAIN")?.takeIf { it.isNotBlank() }?.let {
        return "https://$it"
    }
    return "http://localhost:8080"
}

fun jsonEscape(s: String): String =
    s.replace("\\", "\\\\")
        .replace("\"", "\\\"")
        .replace("\n", "\\n")
        .replace("\r", "\\r")
        .replace("\t", "\\t")

fun extractString(json: String, field: String): String {
    val key = "\"$field\""
    val i = json.indexOf(key)
    if (i < 0) return ""
    val colon = json.indexOf(':', i + key.length)
    val start = json.indexOf('"', colon + 1)
    if (start < 0) return ""
    val sb = StringBuilder()
    var j = start + 1
    while (j < json.length) {
        val c = json[j]
        if (c == '\\' && j + 1 < json.length) {
            sb.append(json[j + 1]); j += 2; continue
        }
        if (c == '"') break
        sb.append(c); j++
    }
    return sb.toString()
}

fun extractStringArray(json: String, field: String): List<String> {
    val key = "\"$field\""
    val i = json.indexOf(key)
    if (i < 0) return emptyList()
    val openBracket = json.indexOf('[', i + key.length)
    val closeBracket = json.indexOf(']', openBracket + 1)
    if (openBracket < 0 || closeBracket < 0) return emptyList()
    val inner = json.substring(openBracket + 1, closeBracket).trim()
    if (inner.isEmpty()) return emptyList()
    val out = mutableListOf<String>()
    val sb = StringBuilder()
    var inStr = false
    var j = 0
    while (j < inner.length) {
        val c = inner[j]
        when {
            c == '\\' && j + 1 < inner.length -> { sb.append(inner[j + 1]); j += 2; continue }
            c == '"' -> { if (inStr) { out.add(sb.toString()); sb.clear() }; inStr = !inStr }
            inStr -> sb.append(c)
        }
        j++
    }
    return out
}

if (args.isEmpty()) {
    System.err.println("Usage: translate.main.kts <bangla text> [casual|neutral|formal]")
    System.exit(1)
}

val text = args[0]
val tone = if (args.size > 1) args[1] else "neutral"
val payload = """{"text":"${jsonEscape(text)}","tone":"$tone"}"""

val conn = URI("${baseUrl()}/api/translate").toURL().openConnection() as HttpURLConnection
conn.requestMethod = "POST"
conn.doOutput = true
conn.setRequestProperty("Content-Type", "application/json")
conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }

val code = conn.responseCode
val stream = if (code in 200..299) conn.inputStream else conn.errorStream
val body = stream.bufferedReader(Charsets.UTF_8).readText()

if (code !in 200..299) {
    System.err.println("HTTP $code: $body")
    System.exit(2)
}

val translation = extractString(body, "translation")
val literal = extractString(body, "literal")
val notes = extractStringArray(body, "notes")

println()
println("  Bangla : $text")
println("  Tone   : $tone")
println()
println("  English: $translation")
println("  Literal: $literal")
if (notes.isNotEmpty()) {
    println("  Notes  :")
    notes.forEach { println("    • $it") }
}
println()
