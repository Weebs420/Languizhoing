# Usage report for the bangla-translator translations table.
#
# Reads DATABASE_URL, computes per-day volume + average input length, and
# prints an ASCII chart. Designed to be re-runnable.
#
# Run:  julia --project=. run.jl

using LibPQ, DataFrames, Dates, Statistics

const DB_URL = get(ENV, "DATABASE_URL", "")
if isempty(DB_URL)
    error("DATABASE_URL is not set")
end

conn = LibPQ.Connection(DB_URL)

println("\n== Bangla Translator Usage Report ==")
println("Generated: ", now())

total = DataFrame(execute(conn, "SELECT count(*) AS n FROM translations"))[1, :n]
println("Total translations: ", total)

if total == 0
    println("(no data yet)")
    LibPQ.close(conn)
    exit()
end

tone_df = DataFrame(execute(conn, """
    SELECT tone, count(*) AS n
    FROM translations
    GROUP BY tone ORDER BY n DESC
"""))
println("\nBy tone:")
for r in eachrow(tone_df)
    println("  ", rpad(r.tone, 10), r.n)
end

daily = DataFrame(execute(conn, """
    SELECT date_trunc('day', created_at)::date AS day,
           count(*) AS n,
           avg(length(bangla_text))::int AS avg_len
    FROM translations
    WHERE created_at > now() - interval '30 days'
    GROUP BY day ORDER BY day
"""))

println("\nLast 30 days:")
maxn = isempty(daily) ? 0 : maximum(daily.n)
for r in eachrow(daily)
    bar_len = maxn == 0 ? 0 : Int(round(r.n / maxn * 40))
    println("  ", r.day, "  ", repeat("█", bar_len), "  ",
            r.n, "  (avg input: ", r.avg_len, " chars)")
end

println("\nMean translations / active day: ",
        round(mean(daily.n), digits=2))

LibPQ.close(conn)
