# usage-report (Julia)

Generates a per-day usage report from the `translations` table.

## Install Julia

Julia isn't a Replit module. Install once:

```bash
curl -fsSL https://install.julialang.org | sh
```

Then from this folder:

```bash
julia --project=. -e 'using Pkg; Pkg.instantiate()'
julia --project=. run.jl
```

`DATABASE_URL` is read from the environment.
