# phrasebook-cheatsheet (JavaScript)

Zero-dependency Node script that pulls the live phrasebook from the API and
emits a printable single-page HTML cheat sheet to stdout. Travelers can pipe
it to a file, open in a browser, and save as PDF for offline use.

## Why plain JS, not TypeScript

The API server is TypeScript end-to-end. This deliberately is not — it is
the "drop on any laptop, run with `node cheatsheet.js`" tool. No build, no
`tsconfig`, no install step. Works on any machine with Node 18+ (which has
the global `fetch`).

## Run

```bash
# whole phrasebook, default tone:
API_URL=https://my-app.replit.app node cheatsheet.js > cheatsheet.html

# just greetings, casual tone:
node cheatsheet.js --category greetings --tone casual > greetings.html

# inside Replit dev:
node cheatsheet.js > sheet.html  # uses $REPLIT_DEV_DOMAIN
```

Open the resulting HTML in a browser → File → Print → Save as PDF.
