#!/usr/bin/env node
/*
 * phrasebook-cheatsheet
 * ---------------------
 * Pure Node.js (no deps) tool that pulls the live phrasebook from the API
 * and writes a printable, single-page HTML cheat sheet to stdout (or a
 * file). Travelers can save it as a PDF and use it offline.
 *
 * Why JavaScript (not TypeScript): this is meant to be a one-file script
 * that anyone can run with `node cheatsheet.js > out.html` — no build
 * step, no tsconfig, no install. Drop it on any machine with Node 18+
 * and it works.
 *
 * Usage:
 *   API_URL=https://my-app.replit.app node cheatsheet.js > sheet.html
 *   node cheatsheet.js --category greetings --tone casual > greetings.html
 */

const args = process.argv.slice(2);
const opts = {};
for (let i = 0; i < args.length; i += 2) opts[args[i].replace(/^--/, "")] = args[i + 1];

const API = process.env.API_URL || `https://${process.env.REPLIT_DEV_DOMAIN || "localhost:5000"}`;
const url = new URL(`${API}/api/phrases`);
if (opts.category) url.searchParams.set("category", opts.category);
if (opts.tone) url.searchParams.set("tone", opts.tone);
url.searchParams.set("limit", opts.limit || "200");

const escapeHtml = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);

const groupBy = (rows, key) => {
  const out = new Map();
  for (const r of rows) {
    const k = r[key] || "other";
    if (!out.has(k)) out.set(k, []);
    out.get(k).push(r);
  }
  return out;
};

(async () => {
  const res = await fetch(url);
  if (!res.ok) {
    console.error(`API ${url}: ${res.status}`);
    process.exit(1);
  }
  const data = await res.json();
  const phrases = data.items || data.phrases || [];
  if (!phrases.length) {
    console.error("no phrases returned — check API_URL");
    process.exit(1);
  }

  const grouped = groupBy(phrases, "category");
  const date = new Date().toISOString().slice(0, 10);

  const css = `
    @page { size: A4; margin: 12mm; }
    body { font: 11pt/1.4 -apple-system, system-ui, sans-serif; color: #111; max-width: 780px; margin: 0 auto; }
    h1 { font-size: 22pt; margin: 0 0 4pt; color: #0f766e; }
    .meta { color: #666; font-size: 9pt; margin-bottom: 12pt; }
    h2 { font-size: 13pt; color: #0f766e; border-bottom: 1px solid #0f766e; padding-bottom: 2pt; margin-top: 14pt; }
    table { width: 100%; border-collapse: collapse; page-break-inside: avoid; }
    td { vertical-align: top; padding: 3pt 4pt; border-bottom: 1px dashed #ddd; }
    .bn { font-size: 12pt; width: 35%; }
    .en { width: 50%; }
    .tone { color: #b45309; font-size: 8pt; text-transform: uppercase; letter-spacing: 0.5pt; width: 15%; text-align: right; }
    @media print { body { max-width: none; } }
  `;

  let html = `<!doctype html><meta charset="utf-8"><title>Bangla → English cheat sheet</title><style>${css}</style>`;
  html += `<h1>Bangla → American English cheat sheet</h1>`;
  html += `<div class="meta">${phrases.length} phrases · generated ${date}`;
  if (opts.tone) html += ` · tone: ${escapeHtml(opts.tone)}`;
  html += `</div>`;

  for (const [cat, rows] of [...grouped.entries()].sort()) {
    html += `<h2>${escapeHtml(cat)}</h2><table>`;
    for (const r of rows) {
      html += `<tr><td class="bn">${escapeHtml(r.bangla || r.source || "")}</td>`;
      html += `<td class="en">${escapeHtml(r.english || r.translation || r.target || "")}</td>`;
      html += `<td class="tone">${escapeHtml(r.tone || "")}</td></tr>`;
    }
    html += `</table>`;
  }

  process.stdout.write(html);
  console.error(`✓ ${phrases.length} phrases in ${grouped.size} categories`);
})().catch((e) => {
  console.error(e.message);
  process.exit(1);
});
