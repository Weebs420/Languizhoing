// vocab-trie
// ----------
// Loads every Oxford 3000/5000 word from words.txt (one per line) into an
// in-memory trie and answers two questions on stdin:
//
//   prefix:<text>   -> all words starting with <text> (sorted, capped at 25)
//   fuzzy:<text>    -> top-5 nearest words by Levenshtein distance
//
// Why C++: the trie + DP table is hot, and the Vocab tab in the mobile app
// wants instant "did you mean…?" suggestions for misspelled queries. The
// Express API server can shell out to this binary instead of N round
// trips to Postgres.
//
// Build:  g++ -O2 -std=c++17 -o vocab_trie vocab_trie.cpp
// Refresh word list (run once whenever vocabulary table changes):
//   psql "$DATABASE_URL" -At -c "SELECT word FROM vocabulary ORDER BY word" > words.txt
// Use:
//   ./vocab_trie words.txt <<< "fuzzy:beleive"

#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

struct Node {
    Node* children[27] = {nullptr};
    bool terminal = false;
};

static int idx(char c) {
    if (c >= 'a' && c <= 'z') return c - 'a';
    if (c == '-') return 26;
    return -1;
}

class Trie {
   public:
    void insert(const std::string& w) {
        Node* cur = &root_;
        for (char c : w) {
            int i = idx(c);
            if (i < 0) return;
            if (!cur->children[i]) cur->children[i] = new Node();
            cur = cur->children[i];
        }
        cur->terminal = true;
    }

    std::vector<std::string> prefix(const std::string& p, size_t cap = 25) const {
        const Node* cur = &root_;
        for (char c : p) {
            int i = idx(c);
            if (i < 0 || !cur->children[i]) return {};
            cur = cur->children[i];
        }
        std::vector<std::string> out;
        std::string buf = p;
        collect(cur, buf, out, cap);
        return out;
    }

   private:
    Node root_;
    static void collect(const Node* n, std::string& buf,
                        std::vector<std::string>& out, size_t cap) {
        if (out.size() >= cap) return;
        if (n->terminal) out.push_back(buf);
        for (int i = 0; i < 27; i++) {
            if (n->children[i]) {
                buf.push_back(i == 26 ? '-' : ('a' + i));
                collect(n->children[i], buf, out, cap);
                buf.pop_back();
            }
        }
    }
};

static int leven(const std::string& a, const std::string& b) {
    std::vector<int> prev(b.size() + 1), cur(b.size() + 1);
    for (size_t j = 0; j <= b.size(); j++) prev[j] = (int)j;
    for (size_t i = 1; i <= a.size(); i++) {
        cur[0] = (int)i;
        for (size_t j = 1; j <= b.size(); j++) {
            int cost = (a[i - 1] == b[j - 1]) ? 0 : 1;
            cur[j] = std::min({cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost});
        }
        std::swap(prev, cur);
    }
    return prev[b.size()];
}

static std::string lower(std::string s) {
    for (auto& c : s) c = (char)std::tolower((unsigned char)c);
    return s;
}

int main(int argc, char** argv) {
    const char* path = argc > 1 ? argv[1] : "words.txt";
    std::ifstream in(path);
    if (!in) { std::cerr << "cannot open " << path << "\n"; return 1; }

    Trie t;
    std::vector<std::string> all;
    std::string w;
    while (std::getline(in, w)) {
        if (w.empty()) continue;
        std::string lw = lower(w);
        t.insert(lw);
        all.push_back(std::move(lw));
    }
    std::cerr << "loaded " << all.size() << " words\n";

    std::string line;
    while (std::getline(std::cin, line)) {
        auto sep = line.find(':');
        if (sep == std::string::npos) continue;
        std::string cmd = line.substr(0, sep);
        std::string arg = lower(line.substr(sep + 1));

        if (cmd == "prefix") {
            auto hits = t.prefix(arg);
            std::cout << "[";
            for (size_t i = 0; i < hits.size(); i++) {
                if (i) std::cout << ",";
                std::cout << "\"" << hits[i] << "\"";
            }
            std::cout << "]\n" << std::flush;
        } else if (cmd == "fuzzy") {
            std::vector<std::pair<int, std::string>> ranked;
            ranked.reserve(all.size());
            for (const auto& word : all) ranked.emplace_back(leven(arg, word), word);
            int top = std::min<int>(5, (int)ranked.size());
            std::partial_sort(ranked.begin(), ranked.begin() + top, ranked.end());
            std::cout << "[";
            for (int i = 0; i < top; i++) {
                if (i) std::cout << ",";
                std::cout << "{\"word\":\"" << ranked[i].second
                          << "\",\"distance\":" << ranked[i].first << "}";
            }
            std::cout << "]\n" << std::flush;
        } else {
            std::cout << "[]\n" << std::flush;
        }
    }
    return 0;
}
