# vocab-trie (C++)

Long-running daemon that holds the Oxford 3000/5000 word list in a 27-way
trie (a..z plus hyphen) and answers two questions per stdin line:

* `prefix:<txt>` — every word that starts with `<txt>`, sorted, capped at 25.
* `fuzzy:<txt>` — top-5 closest words by Levenshtein distance, with score.

The Express API in `artifacts/api-server` keeps one persistent child process
of this binary and pipes queries to it for the Vocab tab's "did you mean…?"
search box. That avoids hitting Postgres for every keystroke.

## Build & run

```bash
cd polyglot/cpp/vocab-trie
g++ -O2 -std=c++17 -o vocab_trie vocab_trie.cpp

# refresh word list whenever vocabulary table changes:
psql "$DATABASE_URL" -At -c "SELECT word FROM vocabulary ORDER BY word" > words.txt

./vocab_trie words.txt <<EOF
prefix:hap
fuzzy:beleive
EOF
```

## Why C++ here

The trie load is one-time (~6k words, well under a millisecond per insert)
but the per-keystroke prefix walk needs to feel instant. A C++ trie + a
flat string vector for Levenshtein keeps memory under a few MB and answers
in microseconds — fast enough that the API can call it synchronously from
inside the request handler.
