module github.com/replit/bangla-translator/cache

go 1.20
