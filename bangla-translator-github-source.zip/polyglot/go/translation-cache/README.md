# translation-cache (Go)

In-memory LRU cache that proxies `POST /api/translate`. Returns the same JSON
as the upstream API but adds an `X-Cache: HIT|MISS` header.

## Run

```bash
cd polyglot/go/translation-cache
UPSTREAM_URL=http://localhost:8080 PORT=9090 go run main.go
```

## Test

```bash
curl -s -X POST localhost:9090/api/translate \
  -H 'content-type: application/json' \
  -d '{"text":"ভাই, কেমন আছিস?","tone":"casual"}' -i | head -20
```

Run the same request twice — the second response will include `X-Cache: HIT`.
