// Translation cache proxy.
//
// Sits in front of the Express API at $UPSTREAM_URL and caches /translate
// responses by SHA256(text|tone) with an LRU + TTL. Returns "X-Cache: HIT"
// or "X-Cache: MISS" so callers can measure hit rate.
//
// Run:
//   UPSTREAM_URL=http://localhost:8080 PORT=9090 go run main.go
package main

import (
	"bytes"
	"container/list"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"io"
	"log"
	"net/http"
	"os"
	"sync"
	"time"
)

const (
	defaultCapacity = 4096
	defaultTTL      = 24 * time.Hour
)

type cachedItem struct {
	key       string
	body      []byte
	expiresAt time.Time
}

type LRU struct {
	mu       sync.Mutex
	capacity int
	ttl      time.Duration
	ll       *list.List
	index    map[string]*list.Element
}

func NewLRU(capacity int, ttl time.Duration) *LRU {
	return &LRU{
		capacity: capacity,
		ttl:      ttl,
		ll:       list.New(),
		index:    make(map[string]*list.Element),
	}
}

func (c *LRU) Get(key string) ([]byte, bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	el, ok := c.index[key]
	if !ok {
		return nil, false
	}
	item := el.Value.(*cachedItem)
	if time.Now().After(item.expiresAt) {
		c.ll.Remove(el)
		delete(c.index, key)
		return nil, false
	}
	c.ll.MoveToFront(el)
	out := make([]byte, len(item.body))
	copy(out, item.body)
	return out, true
}

func (c *LRU) Set(key string, body []byte) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if el, ok := c.index[key]; ok {
		c.ll.MoveToFront(el)
		item := el.Value.(*cachedItem)
		item.body = body
		item.expiresAt = time.Now().Add(c.ttl)
		return
	}
	item := &cachedItem{key: key, body: body, expiresAt: time.Now().Add(c.ttl)}
	el := c.ll.PushFront(item)
	c.index[key] = el
	if c.ll.Len() > c.capacity {
		oldest := c.ll.Back()
		if oldest != nil {
			c.ll.Remove(oldest)
			delete(c.index, oldest.Value.(*cachedItem).key)
		}
	}
}

func (c *LRU) Stats() (int, int) {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.ll.Len(), c.capacity
}

type translateRequest struct {
	Text string `json:"text"`
	Tone string `json:"tone"`
}

func cacheKey(req translateRequest) string {
	h := sha256.New()
	h.Write([]byte(req.Tone))
	h.Write([]byte{'|'})
	h.Write([]byte(req.Text))
	return hex.EncodeToString(h.Sum(nil))
}

func main() {
	upstream := os.Getenv("UPSTREAM_URL")
	if upstream == "" {
		upstream = "http://localhost:8080"
	}
	port := os.Getenv("PORT")
	if port == "" {
		port = "9090"
	}

	cache := NewLRU(defaultCapacity, defaultTTL)
	client := &http.Client{Timeout: 60 * time.Second}

	mux := http.NewServeMux()

	mux.HandleFunc("/healthz", func(w http.ResponseWriter, r *http.Request) {
		size, cap := cache.Stats()
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]any{
			"status":         "ok",
			"cache_size":     size,
			"cache_capacity": cap,
			"upstream":       upstream,
		})
	})

	mux.HandleFunc("/api/translate", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
			return
		}
		raw, err := io.ReadAll(r.Body)
		if err != nil {
			http.Error(w, "bad body", http.StatusBadRequest)
			return
		}
		var req translateRequest
		if err := json.Unmarshal(raw, &req); err != nil || req.Text == "" || req.Tone == "" {
			http.Error(w, "invalid request", http.StatusBadRequest)
			return
		}

		key := cacheKey(req)
		if cached, ok := cache.Get(key); ok {
			w.Header().Set("Content-Type", "application/json")
			w.Header().Set("X-Cache", "HIT")
			_, _ = w.Write(cached)
			return
		}

		upstreamURL := upstream + "/api/translate"
		upstreamReq, err := http.NewRequestWithContext(r.Context(), http.MethodPost, upstreamURL, bytes.NewReader(raw))
		if err != nil {
			http.Error(w, "upstream request failed", http.StatusBadGateway)
			return
		}
		upstreamReq.Header.Set("Content-Type", "application/json")

		resp, err := client.Do(upstreamReq)
		if err != nil {
			log.Printf("upstream error: %v", err)
			http.Error(w, "upstream unreachable", http.StatusBadGateway)
			return
		}
		defer resp.Body.Close()

		body, err := io.ReadAll(resp.Body)
		if err != nil {
			http.Error(w, "upstream read failed", http.StatusBadGateway)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("X-Cache", "MISS")
		w.WriteHeader(resp.StatusCode)
		_, _ = w.Write(body)

		if resp.StatusCode == http.StatusOK {
			cache.Set(key, body)
		}
	})

	log.Printf("translation-cache listening on :%s -> upstream %s", port, upstream)
	if err := http.ListenAndServe(":"+port, mux); err != nil {
		log.Fatal(err)
	}
}
