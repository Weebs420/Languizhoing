// Flutter mobile client for the Bangla → American English translator API.
//
// A second mobile front-end alongside the main Expo app. Same /translate
// endpoint, same tone selector, simplified UI to keep the example focused.

import 'dart:convert';
import 'dart:io' show Platform;

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const TranslatorApp());

String apiBaseUrl() {
  const fromDefine = String.fromEnvironment('API_BASE_URL');
  if (fromDefine.isNotEmpty) return fromDefine.replaceAll(RegExp(r'/+$'), '');
  if (!kIsWeb) {
    final envUrl = Platform.environment['API_BASE_URL'];
    if (envUrl != null && envUrl.isNotEmpty) {
      return envUrl.replaceAll(RegExp(r'/+$'), '');
    }
    final domain = Platform.environment['REPLIT_DEV_DOMAIN'];
    if (domain != null && domain.isNotEmpty) return 'https://$domain';
  }
  return 'http://localhost:8080';
}

const bool kIsWeb = bool.fromEnvironment('dart.library.js_util');

class TranslatorApp extends StatelessWidget {
  const TranslatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Bangla → American',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0F766E)),
        useMaterial3: true,
      ),
      home: const TranslatorScreen(),
    );
  }
}

class TranslatorScreen extends StatefulWidget {
  const TranslatorScreen({super.key});

  @override
  State<TranslatorScreen> createState() => _TranslatorScreenState();
}

class _TranslatorScreenState extends State<TranslatorScreen> {
  final _controller = TextEditingController();
  String _tone = 'neutral';
  bool _loading = false;
  String? _translation;
  String? _literal;
  List<String> _notes = const [];
  String? _error;

  Future<void> _translate() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    setState(() {
      _loading = true;
      _error = null;
      _translation = null;
      _literal = null;
      _notes = const [];
    });
    try {
      final res = await http.post(
        Uri.parse('${apiBaseUrl()}/api/translate'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'text': text, 'tone': _tone}),
      );
      if (res.statusCode != 200) {
        throw Exception('HTTP ${res.statusCode}: ${res.body}');
      }
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      setState(() {
        _translation = data['translation'] as String?;
        _literal = data['literal'] as String?;
        _notes = ((data['notes'] as List?) ?? const [])
            .map((e) => e.toString())
            .toList();
      });
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF0F766E),
        foregroundColor: Colors.white,
        title: const Text('Bangla → American'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            TextField(
              controller: _controller,
              maxLines: 4,
              decoration: const InputDecoration(
                hintText: 'এখানে বাংলায় লিখুন...',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'casual', label: Text('Casual')),
                ButtonSegment(value: 'neutral', label: Text('Neutral')),
                ButtonSegment(value: 'formal', label: Text('Formal')),
              ],
              selected: {_tone},
              onSelectionChanged: (s) => setState(() => _tone = s.first),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              icon: _loading
                  ? const SizedBox(
                      width: 16, height: 16,
                      child: CircularProgressIndicator(
                        strokeWidth: 2, color: Colors.white,
                      ),
                    )
                  : const Icon(Icons.translate),
              label: Text(_loading ? 'Translating…' : 'Translate'),
              onPressed: _loading ? null : _translate,
            ),
            if (_error != null) ...[
              const SizedBox(height: 12),
              Card(
                color: cs.errorContainer,
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Text(_error!, style: TextStyle(color: cs.onErrorContainer)),
                ),
              ),
            ],
            if (_translation != null) ...[
              const SizedBox(height: 16),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('AMERICAN ENGLISH',
                          style: TextStyle(
                              fontSize: 11,
                              letterSpacing: 1,
                              fontWeight: FontWeight.w600)),
                      const SizedBox(height: 6),
                      Text(_translation!,
                          style: const TextStyle(fontSize: 18, height: 1.4)),
                    ],
                  ),
                ),
              ),
            ],
            if (_literal != null) ...[
              const SizedBox(height: 8),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('LITERAL',
                          style: TextStyle(
                              fontSize: 11,
                              letterSpacing: 1,
                              fontWeight: FontWeight.w600)),
                      const SizedBox(height: 6),
                      Text(_literal!,
                          style: const TextStyle(
                              fontSize: 15, fontStyle: FontStyle.italic)),
                    ],
                  ),
                ),
              ),
            ],
            if (_notes.isNotEmpty) ...[
              const SizedBox(height: 8),
              Card(
                color: const Color(0xFFFEF3C7),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('TRANSLATOR\'S NOTES',
                          style: TextStyle(
                              fontSize: 11,
                              letterSpacing: 1,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFF7C2D12))),
                      const SizedBox(height: 6),
                      ..._notes.map(
                        (n) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 2),
                          child: Text('• $n',
                              style: const TextStyle(color: Color(0xFF7C2D12))),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
