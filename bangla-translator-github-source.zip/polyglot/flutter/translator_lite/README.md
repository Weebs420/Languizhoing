# translator_lite (Flutter)

A second mobile client for the same translator API, written in Dart with
Flutter. Serves as a reference port of the main Expo app's translate screen.

## Install Flutter

Flutter isn't a Replit module. Install once:

```bash
git clone https://github.com/flutter/flutter.git -b stable ~/flutter
export PATH="$PATH:$HOME/flutter/bin"
flutter doctor
```

## Run

```bash
cd polyglot/flutter/translator_lite
flutter pub get
flutter run --dart-define=API_BASE_URL=https://$REPLIT_DEV_DOMAIN
```

For mobile builds, point `API_BASE_URL` at your deployed `.replit.app` URL.
