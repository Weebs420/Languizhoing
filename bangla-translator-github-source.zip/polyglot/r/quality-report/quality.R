# Translation quality report for the bangla-translator app.
#
# Reads DATABASE_URL via DBI/RPostgres, analyzes:
#   - input length distribution
#   - expansion ratio (english chars / bangla chars) per tone
#   - notes per translation (richness signal)
# and writes a Markdown report to ./quality-report.md
#
# Run:  Rscript quality.R

suppressPackageStartupMessages({
  library(DBI)
  library(RPostgres)
})

db_url <- Sys.getenv("DATABASE_URL")
if (db_url == "") stop("DATABASE_URL is not set")

con <- dbConnect(RPostgres::Postgres(), dbname = db_url)
on.exit(dbDisconnect(con))

df <- dbGetQuery(con, "
  SELECT id, tone,
         length(bangla_text)  AS bn_len,
         length(english_text) AS en_len,
         coalesce(jsonb_array_length(notes), 0) AS notes_count,
         created_at
  FROM translations
")

out <- file("quality-report.md", "w")
on.exit(close(out), add = TRUE)

writeLines(c(
  "# Translation Quality Report",
  paste0("_Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S UTC", tz = "UTC"), "_"),
  ""
), out)

if (nrow(df) == 0) {
  writeLines("No translations logged yet.", out)
  cat("Wrote quality-report.md (no data)\n")
  quit(status = 0)
}

writeLines(c(
  "## Summary",
  "",
  paste0("- Total translations: **", nrow(df), "**"),
  paste0("- Avg Bangla input length: **", round(mean(df$bn_len), 1), "** chars"),
  paste0("- Avg English output length: **", round(mean(df$en_len), 1), "** chars"),
  paste0("- Avg notes per translation: **", round(mean(df$notes_count), 2), "**"),
  ""
), out)

writeLines(c("## Expansion ratio by tone", "", "| Tone | n | avg ratio | min | max |", "|---|---|---|---|---|"), out)
for (t in unique(df$tone)) {
  sub <- df[df$tone == t & df$bn_len > 0, ]
  ratio <- sub$en_len / sub$bn_len
  writeLines(sprintf("| %s | %d | %.2f | %.2f | %.2f |",
                     t, nrow(sub), mean(ratio), min(ratio), max(ratio)), out)
}

writeLines(c("", "## Length distribution (Bangla input, chars)", ""), out)
qs <- quantile(df$bn_len, c(0.25, 0.5, 0.75, 0.9, 0.99))
writeLines(c(
  paste0("- p25: ", round(qs[1])),
  paste0("- p50: ", round(qs[2])),
  paste0("- p75: ", round(qs[3])),
  paste0("- p90: ", round(qs[4])),
  paste0("- p99: ", round(qs[5]))
), out)

cat("Wrote quality-report.md\n")
