# quality-report (R)

R script that reads the `translations` table and writes a Markdown report
(`quality-report.md`) with input-length distribution and expansion ratios.

## Install R

R isn't a Replit module. Install once:

```bash
# Debian/Ubuntu/NixOS
nix-env -iA nixpkgs.R
# then in R:
install.packages(c("DBI", "RPostgres"))
```

## Run

```bash
cd polyglot/r/quality-report
DATABASE_URL=$DATABASE_URL Rscript quality.R
cat quality-report.md
```
