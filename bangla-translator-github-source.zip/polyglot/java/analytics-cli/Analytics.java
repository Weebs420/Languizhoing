// Analytics CLI for the bangla-translator `translations` table.
//
// Reads DATABASE_URL (any postgres://… URL) and prints a summary:
//   - total translations
//   - distribution by tone
//   - daily counts (last 14 days)
//   - top 5 longest Bangla inputs
//
// Build & run:
//   javac Analytics.java
//   java -cp ".:postgresql-42.7.4.jar" Analytics
//
// Requires the Postgres JDBC driver (postgresql-42.x.jar) on the classpath.

import java.net.URI;
import java.sql.*;
import java.time.LocalDate;
import java.util.*;

public class Analytics {

    public static void main(String[] args) throws Exception {
        String dbUrl = System.getenv("DATABASE_URL");
        if (dbUrl == null || dbUrl.isEmpty()) {
            System.err.println("DATABASE_URL is not set");
            System.exit(1);
        }

        // Convert postgres://user:pass@host:port/db -> jdbc:postgresql://host:port/db + props
        URI uri = new URI(dbUrl);
        String userInfo = uri.getUserInfo();
        String user = "", password = "";
        if (userInfo != null && userInfo.contains(":")) {
            String[] up = userInfo.split(":", 2);
            user = up[0];
            password = up[1];
        }
        String jdbcUrl = "jdbc:postgresql://" + uri.getHost() +
                (uri.getPort() > 0 ? ":" + uri.getPort() : "") +
                uri.getPath() + "?sslmode=require";

        try (Connection conn = DriverManager.getConnection(jdbcUrl, user, password)) {
            printHeader("Bangla Translator — Analytics");

            long total = scalarLong(conn, "SELECT count(*) FROM translations");
            System.out.println("Total translations: " + total);

            if (total == 0) {
                System.out.println("(no data yet — run the app to log some translations)");
                return;
            }

            printSection("By tone");
            try (Statement st = conn.createStatement();
                 ResultSet rs = st.executeQuery(
                     "SELECT tone, count(*) FROM translations GROUP BY tone ORDER BY count(*) DESC")) {
                while (rs.next()) {
                    System.out.printf("  %-8s %6d%n", rs.getString(1), rs.getLong(2));
                }
            }

            printSection("Daily counts (last 14 days)");
            try (Statement st = conn.createStatement();
                 ResultSet rs = st.executeQuery(
                     "SELECT date_trunc('day', created_at)::date AS d, count(*) " +
                     "FROM translations " +
                     "WHERE created_at > now() - interval '14 days' " +
                     "GROUP BY d ORDER BY d")) {
                while (rs.next()) {
                    LocalDate d = rs.getDate(1).toLocalDate();
                    long c = rs.getLong(2);
                    System.out.printf("  %s  %s%n", d, bar(c));
                }
            }

            printSection("Top 5 longest Bangla inputs");
            try (Statement st = conn.createStatement();
                 ResultSet rs = st.executeQuery(
                     "SELECT length(bangla_text) AS len, " +
                     "       left(bangla_text, 60) AS preview " +
                     "FROM translations ORDER BY len DESC LIMIT 5")) {
                while (rs.next()) {
                    System.out.printf("  [%4d chars] %s…%n", rs.getInt(1), rs.getString(2));
                }
            }
        }
    }

    static long scalarLong(Connection conn, String sql) throws SQLException {
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            return rs.next() ? rs.getLong(1) : 0;
        }
    }

    static String bar(long n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(n, 60); i++) sb.append('█');
        return sb.append("  ").append(n).toString();
    }

    static void printHeader(String s) {
        System.out.println();
        System.out.println("=".repeat(s.length()));
        System.out.println(s);
        System.out.println("=".repeat(s.length()));
    }

    static void printSection(String s) {
        System.out.println();
        System.out.println("-- " + s + " --");
    }
}
