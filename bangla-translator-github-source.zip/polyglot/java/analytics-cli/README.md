# analytics-cli (Java)

Single-file Java program that connects to the Replit Postgres `translations`
table and prints a usage summary (totals, tone distribution, daily counts,
longest inputs).

## Run

Download the Postgres JDBC driver once:

```bash
cd polyglot/java/analytics-cli
curl -L -o postgresql-42.7.4.jar \
  https://jdbc.postgresql.org/download/postgresql-42.7.4.jar
```

Then compile and run:

```bash
javac Analytics.java
java -cp ".:postgresql-42.7.4.jar" Analytics
```

`DATABASE_URL` is read from the environment.
