#!/usr/bin/env bash
# Pre-deploy sanity checks: typecheck, build, schema push, smoke test the API.

set -euo pipefail
cd "$(git rev-parse --show-toplevel)"

echo "==> Typecheck"
pnpm run typecheck

echo "==> Build"
pnpm run build

echo "==> DB push (dev)"
pnpm --filter @workspace/db run push

echo "==> API smoke test"
PORT="${PORT:-8080}"
curl -fsS "http://localhost:$PORT/api/healthz" | jq . || true

echo "==> Ready to deploy."
