#!/usr/bin/env bash
# Run every data-pipeline job and report timing.
# Suitable for cron / Replit Scheduled Deployments.

set -euo pipefail

START=$(date +%s)
echo "==> Refreshing translator data at $(date -u +%FT%TZ)"

cd "$(dirname "$0")/../../data-pipeline"
uv run python run_all.py

END=$(date +%s)
echo "==> Done in $((END - START))s"
