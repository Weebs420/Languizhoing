#!/usr/bin/env bash
# Dump the Postgres database to a timestamped .sql.gz file.
# Usage: ./polyglot/bash/backup-db.sh [output_dir]

set -euo pipefail

if [[ -z "${DATABASE_URL:-}" ]]; then
  echo "DATABASE_URL is not set" >&2
  exit 1
fi

OUT_DIR="${1:-./backups}"
mkdir -p "$OUT_DIR"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT_FILE="$OUT_DIR/bangla_translator_$STAMP.sql.gz"

echo "Backing up to $OUT_FILE ..."
pg_dump --no-owner --no-privileges "$DATABASE_URL" | gzip > "$OUT_FILE"

SIZE=$(du -h "$OUT_FILE" | cut -f1)
echo "Done. Wrote $OUT_FILE ($SIZE)"
