# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally
- `cd data-pipeline && uv run python run_daily.py` — add 50+ vocabulary and
  phrasebook translations and refresh news
- `cd data-pipeline && uv run python run_all.py` — run the complete data refresh

## User preferences

- Keep existing vocabulary rows in their current order. Add future vocabulary
  words alphabetically by word, without re-sorting the existing data.
- Keep the current product focused on Bangla ↔ American English for now. Future
  translation directions, in priority order, are Bangla → English, Spanish →
  English, English → Bangla, Spanish → Bangla, Bangla → Bangla, Bangla →
  Spanish, English → Spanish, and Spanish → Spanish. More languages may be
  added later; Spanish material is reference data for now.

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.

## Bangla Translator App

Mobile (Expo) app with three tabs: Translate, Phrasebook, News.

- **Translate tab** (`app/(tabs)/index.tsx`): Bangla → American English with tone selector
  (casual / neutral / formal). Backed by `POST /api/translate` which calls Anthropic
  (claude-sonnet-4-6) and logs every translation to the `translations` table.
- **Phrasebook tab** (`app/(tabs)/phrasebook.tsx`): browseable list of curated Bangla
  idioms / slang / Gen Z phrases from the `phrasebook` table. Filter by category, search,
  tap to copy. Source: `GET /api/phrasebook`.
- **News tab** (`app/(tabs)/news.tsx`): pre-translated Bangla headlines from the
  `news_items` table. "Show Bangla" toggle, source links. Source: `GET /api/news`.

### Data pipeline (`data-pipeline/`)

Python jobs that keep the app's data fresh. Use `python-3.11` via `uv`. Env vars
required: `DATABASE_URL`, `AI_INTEGRATIONS_ANTHROPIC_BASE_URL`,
`AI_INTEGRATIONS_ANTHROPIC_API_KEY`.

- `expand_phrasebook.py` — uses Claude to add new phrases (deduped via unique index).
- `fetch_news.py` — pulls Bangla RSS (Prothom Alo, BDNews24, Banglanews24) and
  pre-translates titles/summaries.
- `run_daily.py` — daily job; adds 50+ new vocabulary words with Bangla
  meanings, 50+ phrasebook translations, and refreshes news.
- `run_all.py` — runs every job; suitable for a full manual refresh.

### Database tables

- `translations` — every user translation logged for analytics.
- `phrasebook` — Bangla phrase, English equivalent, category, optional example.
- `news_items` — source URL, Bangla and English title/summary, published timestamp.

## Polyglot Toolkit (`polyglot/`)

Companion programs in many languages, all sharing the same database and API.
See `polyglot/README.md` for the full list. Highlights:

- **Bash** (`polyglot/bash/`) — DB backup, scheduled refresh, deploy prep.
- **Python** (`polyglot/python/cli-translate/`) — stdlib CLI client.
- **Go** (`polyglot/go/translation-cache/`) — LRU cache proxy for `/translate`,
  adds `X-Cache: HIT|MISS` headers. Build: `go build` from that folder.
- **Java** (`polyglot/java/analytics-cli/`) — JDBC analytics CLI for the
  `translations` table. Requires `postgresql-42.x.jar` on classpath.
- **Julia** (`polyglot/julia/usage-report/`) — per-day usage chart (requires
  manual Julia install).
- **R** (`polyglot/r/quality-report/`) — writes `quality-report.md` (requires
  manual R install).
- **Swift** (`polyglot/swift/cli-translate/`) — iOS-style CLI client.
- **Kotlin** (`polyglot/kotlin/cli-translate/`) — Android-style CLI script
  (requires manual Kotlin install via SDKMAN!).
- **Dart/Flutter** (`polyglot/flutter/translator_lite/`) — second mobile
  client (requires manual Flutter SDK install).
