import { Router, type IRouter } from "express";
import {
  db,
  dictionaryWordsTable,
  dictionaryMeaningsTable,
  dictionaryExamplesTable,
  dictionarySynonymsTable,
  dictionaryAntonymsTable,
} from "@workspace/db";
import { and, asc, eq, ilike, sql, type SQL } from "drizzle-orm";

const router: IRouter = Router();

router.get("/dictionary", async (req, res, next) => {
  try {
    const limitRaw = Number(req.query.limit ?? 50);
    const limit = Math.min(
      Math.max(Number.isFinite(limitRaw) ? limitRaw : 50, 1),
      200,
    );

    const offsetRaw = Number(req.query.offset ?? 0);
    const offset = Math.max(Number.isFinite(offsetRaw) ? offsetRaw : 0, 0);

    const search =
      typeof req.query.search === "string" && req.query.search.trim()
        ? req.query.search.trim()
        : undefined;

    const letter =
      typeof req.query.letter === "string" && req.query.letter.trim()
        ? req.query.letter.trim().slice(0, 2)
        : undefined;

    const conditions: SQL[] = [];
    if (search) conditions.push(ilike(dictionaryWordsTable.word, `${search}%`));
    if (letter) conditions.push(ilike(dictionaryWordsTable.word, `${letter}%`));
    const where = conditions.length ? and(...conditions) : undefined;

    const items = await db
      .select()
      .from(dictionaryWordsTable)
      .where(where)
      .orderBy(asc(dictionaryWordsTable.word))
      .limit(limit)
      .offset(offset);

    const [{ count }] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(dictionaryWordsTable)
      .where(where);

    res.json({
      total: Number(count) || 0,
      items: items.map((i) => ({
        id: i.id,
        word: i.word,
        pronunciation: i.pronunciation,
        partOfSpeech: i.partOfSpeech,
      })),
    });
  } catch (err) {
    next(err);
  }
});

router.get("/dictionary/:id", async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isFinite(id) || id <= 0) {
      res.status(400).json({ error: "invalid id" });
      return;
    }

    const [word] = await db
      .select()
      .from(dictionaryWordsTable)
      .where(eq(dictionaryWordsTable.id, id))
      .limit(1);
    if (!word) {
      res.status(404).json({ error: "not found" });
      return;
    }

    const [meanings, examples, synonyms, antonyms] = await Promise.all([
      db
        .select()
        .from(dictionaryMeaningsTable)
        .where(eq(dictionaryMeaningsTable.wordId, id))
        .orderBy(asc(dictionaryMeaningsTable.meaningOrder)),
      db
        .select()
        .from(dictionaryExamplesTable)
        .where(eq(dictionaryExamplesTable.wordId, id))
        .orderBy(asc(dictionaryExamplesTable.id)),
      db
        .select()
        .from(dictionarySynonymsTable)
        .where(eq(dictionarySynonymsTable.wordId, id))
        .orderBy(asc(dictionarySynonymsTable.id)),
      db
        .select()
        .from(dictionaryAntonymsTable)
        .where(eq(dictionaryAntonymsTable.wordId, id))
        .orderBy(asc(dictionaryAntonymsTable.id)),
    ]);

    res.json({
      id: word.id,
      word: word.word,
      pronunciation: word.pronunciation,
      partOfSpeech: word.partOfSpeech,
      origin: word.origin,
      meanings: meanings.map((m) => ({
        id: m.id,
        meaning: m.meaning,
        order: m.meaningOrder,
      })),
      examples: examples.map((e) => ({ id: e.id, example: e.example })),
      synonyms: synonyms.map((s) => s.synonym),
      antonyms: antonyms.map((a) => a.antonym),
    });
  } catch (err) {
    next(err);
  }
});

export default router;
