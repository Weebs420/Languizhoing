import { Router, type IRouter } from "express";
import { db, newsTable } from "@workspace/db";
import { desc, sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/news", async (req, res, next) => {
  try {
    const limitRaw = Number(req.query.limit ?? 30);
    const limit = Math.min(Math.max(Number.isFinite(limitRaw) ? limitRaw : 30, 1), 100);

    const items = await db
      .select()
      .from(newsTable)
      .orderBy(
        desc(sql`COALESCE(${newsTable.publishedAt}, ${newsTable.createdAt})`),
      )
      .limit(limit);

    const [{ count }] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(newsTable);

    res.json({
      total: Number(count) || 0,
      items: items.map((i) => ({
        id: i.id,
        sourceUrl: i.sourceUrl,
        titleBn: i.titleBn,
        titleEn: i.titleEn,
        summaryBn: i.summaryBn,
        summaryEn: i.summaryEn,
        publishedAt: i.publishedAt ? i.publishedAt.toISOString() : null,
        createdAt: i.createdAt.toISOString(),
      })),
    });
  } catch (err) {
    next(err);
  }
});

export default router;
