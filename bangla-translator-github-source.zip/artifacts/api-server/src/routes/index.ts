import { Router, type IRouter } from "express";
import healthRouter from "./health";
import translateRouter from "./translate";
import phrasebookRouter from "./phrasebook";
import newsRouter from "./news";
import vocabularyRouter from "./vocabulary";
import dictionaryRouter from "./dictionary";
import grammarRouter from "./grammar";

const router: IRouter = Router();

router.use(healthRouter);
router.use(translateRouter);
router.use(phrasebookRouter);
router.use(newsRouter);
router.use(vocabularyRouter);
router.use(dictionaryRouter);
router.use(grammarRouter);

export default router;
