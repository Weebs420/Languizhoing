import { Router, type IRouter } from "express";
import { TranslateBanglaBody, TranslateBanglaResponse } from "@workspace/api-zod";
import { anthropic } from "@workspace/integrations-anthropic-ai";
import { db, translationsTable } from "@workspace/db";

const router: IRouter = Router();

const SYSTEM_PROMPT = `You are an expert literary translator specializing in Bangla (Bengali) to American English and broadly understandable Spanish.

Your goal is to render Bangla text into NATIVE-SOUNDING American English — the way a fluent American would actually say it. Embrace:
- Natural contractions ("I'm", "don't", "wouldn't", "it's")
- Phrasal verbs over formal synonyms ("figure out" instead of "determine")
- Idioms and conversational shortcuts when they fit ("piece of cake", "a heads up", "no big deal")
- Informal reductions in casual register only ("gonna", "wanna", "kinda" — only for tone=casual)
- Natural rhythm — Americans don't speak in stiff complete sentences

Match the requested register strictly:
- "casual": friendly, relaxed, like talking to a friend. Contractions, slang okay, possible "gonna/wanna".
- "neutral": clear conversational English suitable for everyday speech and most messages. Contractions yes, slang sparingly.
- "formal": polished, professional. Full words, no slang, courteous phrasing — but still natural, not stiff.

Translate meaning and emotional tone — not word-for-word. Preserve cultural intent (e.g., "ভাই" addressed to a stranger is friendly, not literally "brother"; render as "man", "buddy", or omit). Handle Banglish naturally — English words inside Bangla sentences should flow into the output.

Return ONLY a strict JSON object with these exact fields:
{
  "translation": "the natural American English translation",
  "literal": "a more literal English rendering for reference (still grammatical English, just closer to the original wording)",
  "spanish": "a natural Spanish translation that is broadly understandable across Spanish-speaking countries; prefer neutral Latin American Spanish",
  "notes": ["brief note about an idiom, slang, or cultural choice", "another note if relevant"]
}

The "notes" array should have 0–4 short entries. No markdown, no code fences, no extra text outside the JSON.`;

router.post("/translate", async (req, res, next) => {
  try {
    const body = TranslateBanglaBody.parse(req.body);

    const message = await anthropic.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 8192,
      system: SYSTEM_PROMPT,
      messages: [
        {
          role: "user",
          content: `Tone: ${body.tone}\n\nBangla text:\n${body.text}`,
        },
      ],
    });

    const block = message.content[0];
    const raw = block && block.type === "text" ? block.text : "";

    const jsonStart = raw.indexOf("{");
    const jsonEnd = raw.lastIndexOf("}");
    if (jsonStart === -1 || jsonEnd === -1) {
      req.log.error({ raw }, "Translator returned non-JSON response");
      res.status(502).json({ error: "Translator returned an unexpected response." });
      return;
    }

    const jsonText = raw.slice(jsonStart, jsonEnd + 1);
    const parsed = JSON.parse(jsonText) as unknown;
    const result = TranslateBanglaResponse.parse(parsed);

    db.insert(translationsTable)
      .values({
        banglaText: body.text,
        englishText: result.translation,
        literalText: result.literal,
        notes: result.notes,
        tone: body.tone,
      })
      .catch((err) => {
        req.log.warn({ err }, "Failed to log translation");
      });

    res.json(result);
  } catch (err) {
    next(err);
  }
});

export default router;
