import { Router, type IRouter } from "express";
import {
  db,
  grammarChaptersTable,
  grammarSectionsTable,
  grammarTopicsTable,
  grammarRulesTable,
  grammarExamplesTable,
} from "@workspace/db";
import { asc, eq } from "drizzle-orm";

const router: IRouter = Router();

router.get("/grammar", async (_req, res, next) => {
  try {
    const [chapters, sections, topics] = await Promise.all([
      db
        .select()
        .from(grammarChaptersTable)
        .orderBy(asc(grammarChaptersTable.ordinal), asc(grammarChaptersTable.id)),
      db
        .select()
        .from(grammarSectionsTable)
        .orderBy(asc(grammarSectionsTable.ordinal), asc(grammarSectionsTable.id)),
      db
        .select({
          id: grammarTopicsTable.id,
          sectionId: grammarTopicsTable.sectionId,
          title: grammarTopicsTable.title,
          ordinal: grammarTopicsTable.ordinal,
        })
        .from(grammarTopicsTable)
        .orderBy(asc(grammarTopicsTable.ordinal), asc(grammarTopicsTable.id)),
    ]);

    res.json({
      chapters: chapters.map((c) => ({
        id: c.id,
        title: c.title,
        description: c.description,
        sections: sections
          .filter((s) => s.chapterId === c.id)
          .map((s) => ({
            id: s.id,
            title: s.title,
            topics: topics
              .filter((t) => t.sectionId === s.id)
              .map((t) => ({ id: t.id, title: t.title })),
          })),
      })),
    });
  } catch (err) {
    next(err);
  }
});

router.get("/grammar/topics/:id", async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isFinite(id) || id <= 0) {
      res.status(400).json({ error: "invalid id" });
      return;
    }

    const [topic] = await db
      .select()
      .from(grammarTopicsTable)
      .where(eq(grammarTopicsTable.id, id))
      .limit(1);
    if (!topic) {
      res.status(404).json({ error: "not found" });
      return;
    }

    const [rules, examples] = await Promise.all([
      db
        .select()
        .from(grammarRulesTable)
        .where(eq(grammarRulesTable.topicId, id))
        .orderBy(asc(grammarRulesTable.id)),
      db
        .select()
        .from(grammarExamplesTable)
        .where(eq(grammarExamplesTable.topicId, id))
        .orderBy(asc(grammarExamplesTable.id)),
    ]);

    res.json({
      id: topic.id,
      sectionId: topic.sectionId,
      title: topic.title,
      content: topic.content,
      rules: rules.map((r) => ({ id: r.id, ruleText: r.ruleText })),
      examples: examples.map((e) => ({
        id: e.id,
        exampleText: e.exampleText,
        explanation: e.explanation,
      })),
    });
  } catch (err) {
    next(err);
  }
});

export default router;
