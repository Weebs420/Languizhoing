import { Router, type IRouter } from "express";
import { db, vocabularyTable } from "@workspace/db";
import { and, asc, eq, ilike, sql, type SQL } from "drizzle-orm";

const router: IRouter = Router();

const ALLOWED_CEFR = new Set(["a1", "a2", "b1", "b2", "c1"]);

router.get("/vocabulary", async (req, res, next) => {
  try {
    const limitRaw = Number(req.query.limit ?? 100);
    const limit = Math.min(
      Math.max(Number.isFinite(limitRaw) ? limitRaw : 100, 1),
      500,
    );

    const offsetRaw = Number(req.query.offset ?? 0);
    const offset = Math.max(Number.isFinite(offsetRaw) ? offsetRaw : 0, 0);

    const cefr =
      typeof req.query.cefr === "string" &&
      ALLOWED_CEFR.has(req.query.cefr.toLowerCase())
        ? req.query.cefr.toLowerCase()
        : undefined;

    const list =
      typeof req.query.list === "string" ? req.query.list.toLowerCase() : "";

    const search =
      typeof req.query.search === "string" && req.query.search.trim()
        ? req.query.search.trim()
        : undefined;

    const conditions: SQL[] = [];
    if (cefr) conditions.push(eq(vocabularyTable.cefr, cefr));
    if (list === "3000") conditions.push(eq(vocabularyTable.inOxford3000, true));
    if (list === "5000") conditions.push(eq(vocabularyTable.inOxford5000, true));
    if (search) conditions.push(ilike(vocabularyTable.word, `${search}%`));

    const where = conditions.length ? and(...conditions) : undefined;

    const items = await db
      .select()
      .from(vocabularyTable)
      .where(where)
      .orderBy(asc(vocabularyTable.word), asc(vocabularyTable.pos))
      .limit(limit)
      .offset(offset);

    const [{ count }] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(vocabularyTable)
      .where(where);

    res.json({
      total: Number(count) || 0,
      items: items.map((i) => ({
        id: i.id,
        word: i.word,
        pos: i.pos,
        cefr: i.cefr,
        inOxford3000: i.inOxford3000,
        inOxford5000: i.inOxford5000,
        audioUk: i.audioUk,
        audioUs: i.audioUs,
        banglaMeaning: i.banglaMeaning,
      })),
    });
  } catch (err) {
    next(err);
  }
});

export default router;
