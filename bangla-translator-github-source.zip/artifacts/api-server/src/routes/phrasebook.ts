import { Router, type IRouter } from "express";
import { db, phrasebookTable } from "@workspace/db";
import { desc, eq, sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/phrasebook", async (req, res, next) => {
  try {
    const limitRaw = Number(req.query.limit ?? 100);
    const limit = Math.min(Math.max(Number.isFinite(limitRaw) ? limitRaw : 100, 1), 200);
    const category =
      typeof req.query.category === "string" && req.query.category.trim()
        ? req.query.category.trim().toLowerCase()
        : undefined;

    const where = category ? eq(phrasebookTable.category, category) : undefined;

    const items = await db
      .select()
      .from(phrasebookTable)
      .where(where)
      .orderBy(desc(phrasebookTable.createdAt))
      .limit(limit);

    const [{ count }] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(phrasebookTable)
      .where(where);

    res.json({
      total: Number(count) || 0,
      items: items.map((i) => ({
        id: i.id,
        bangla: i.bangla,
        english: i.english,
        category: i.category,
        example: i.example,
        createdAt: i.createdAt.toISOString(),
      })),
    });
  } catch (err) {
    next(err);
  }
});

export default router;
