const colors = {
  light: {
    text: "#0f172a",
    tint: "#0ea5a4",

    background: "#f6f7f9",
    foreground: "#0f172a",

    card: "#ffffff",
    cardForeground: "#0f172a",

    primary: "#0f766e",
    primaryForeground: "#ffffff",

    secondary: "#e2e8f0",
    secondaryForeground: "#0f172a",

    muted: "#eef2f5",
    mutedForeground: "#64748b",

    accent: "#fef3c7",
    accentForeground: "#7c2d12",

    destructive: "#ef4444",
    destructiveForeground: "#ffffff",

    border: "#e2e8f0",
    input: "#e2e8f0",
  },
  radius: 16,
};

export default colors;
