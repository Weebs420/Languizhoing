import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import React, { useMemo, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Linking,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useListNews } from "@workspace/api-client-react";

import { useColors } from "@/hooks/useColors";

type NewsItem = {
  id: number;
  sourceUrl: string;
  titleBn: string;
  titleEn: string;
  summaryBn?: string | null;
  summaryEn?: string | null;
  publishedAt?: string | null;
};

function timeAgo(iso?: string | null): string {
  if (!iso) return "";
  const t = new Date(iso).getTime();
  if (Number.isNaN(t)) return "";
  const seconds = Math.max(1, Math.floor((Date.now() - t) / 1000));
  if (seconds < 60) return `${seconds}s ago`;
  const m = Math.floor(seconds / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}

export default function NewsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const styles = useMemo(() => createStyles(colors), [colors]);

  const query = useListNews({ limit: 50 });
  const items = (query.data?.items ?? []) as NewsItem[];

  const [showBnFor, setShowBnFor] = useState<Record<number, boolean>>({});

  const onOpen = async (url: string) => {
    if (Platform.OS !== "web") Haptics.selectionAsync();
    try {
      await Linking.openURL(url);
    } catch {
      /* noop */
    }
  };

  const webTopInset = Platform.OS === "web" ? 67 : insets.top;

  return (
    <View style={[styles.root, { paddingTop: webTopInset }]}>
      <LinearGradient
        colors={["#0f766e", "#0ea5a4"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.header}
      >
        <Text style={styles.headerTitle}>Bangla News, in English</Text>
        <Text style={styles.headerSubtitle}>
          Headlines from Prothom Alo, BDNews24 & more — pre-translated
        </Text>
      </LinearGradient>

      {query.isPending ? (
        <View style={styles.center}>
          <ActivityIndicator color={colors.primary} />
        </View>
      ) : query.isError ? (
        <View style={styles.center}>
          <Text style={styles.emptyTitle}>Couldn't load news</Text>
          <Pressable
            onPress={() => query.refetch()}
            style={({ pressed }) => [
              styles.retryBtn,
              pressed && { opacity: 0.7 },
            ]}
          >
            <Text style={styles.retryBtnText}>Retry</Text>
          </Pressable>
        </View>
      ) : items.length === 0 ? (
        <View style={styles.center}>
          <Feather name="rss" size={28} color={colors.mutedForeground} />
          <Text style={styles.emptyTitle}>No headlines yet</Text>
          <Text style={styles.emptyHint}>
            The pipeline will fetch fresh stories soon.
          </Text>
        </View>
      ) : (
        <FlatList
          data={items}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          refreshing={query.isFetching}
          onRefresh={() => query.refetch()}
          renderItem={({ item }) => {
            const showBn = !!showBnFor[item.id];
            return (
              <View style={styles.card}>
                <View style={styles.metaRow}>
                  <Feather
                    name="clock"
                    size={11}
                    color={colors.mutedForeground}
                  />
                  <Text style={styles.metaText}>
                    {timeAgo(item.publishedAt)}
                  </Text>
                </View>
                <Text style={styles.titleEn}>{item.titleEn}</Text>
                {item.summaryEn ? (
                  <Text style={styles.summary}>{item.summaryEn}</Text>
                ) : null}
                {showBn ? (
                  <View style={styles.bnBlock}>
                    <Text style={styles.bnLabel}>BANGLA</Text>
                    <Text style={styles.bnTitle}>{item.titleBn}</Text>
                    {item.summaryBn ? (
                      <Text style={styles.bnSummary}>{item.summaryBn}</Text>
                    ) : null}
                  </View>
                ) : null}
                <View style={styles.actionRow}>
                  <Pressable
                    onPress={() =>
                      setShowBnFor((s) => ({ ...s, [item.id]: !showBn }))
                    }
                    style={({ pressed }) => [
                      styles.actionBtn,
                      pressed && { opacity: 0.7 },
                    ]}
                  >
                    <Feather
                      name={showBn ? "eye-off" : "eye"}
                      size={13}
                      color={colors.mutedForeground}
                    />
                    <Text style={styles.actionText}>
                      {showBn ? "Hide Bangla" : "Show Bangla"}
                    </Text>
                  </Pressable>
                  <Pressable
                    onPress={() => onOpen(item.sourceUrl)}
                    style={({ pressed }) => [
                      styles.actionBtn,
                      pressed && { opacity: 0.7 },
                    ]}
                  >
                    <Feather
                      name="external-link"
                      size={13}
                      color={colors.primary}
                    />
                    <Text
                      style={[styles.actionText, { color: colors.primary }]}
                    >
                      Source
                    </Text>
                  </Pressable>
                </View>
              </View>
            );
          }}
        />
      )}
    </View>
  );
}

function createStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: colors.background },
    header: {
      paddingHorizontal: 20,
      paddingTop: 18,
      paddingBottom: 22,
      borderBottomLeftRadius: 24,
      borderBottomRightRadius: 24,
      gap: 4,
    },
    headerTitle: {
      fontFamily: "Inter_700Bold",
      fontSize: 22,
      color: "#fff",
      letterSpacing: -0.4,
    },
    headerSubtitle: {
      fontFamily: "Inter_400Regular",
      fontSize: 13,
      color: "rgba(255,255,255,0.85)",
    },
    listContent: { padding: 16, gap: 12, paddingBottom: 80 },
    card: {
      backgroundColor: colors.card,
      borderRadius: colors.radius,
      padding: 16,
      borderWidth: 1,
      borderColor: colors.border,
      gap: 8,
    },
    metaRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 4,
    },
    metaText: {
      fontFamily: "Inter_500Medium",
      fontSize: 11,
      color: colors.mutedForeground,
    },
    titleEn: {
      fontFamily: "Inter_600SemiBold",
      fontSize: 17,
      lineHeight: 24,
      color: colors.foreground,
      letterSpacing: -0.2,
    },
    summary: {
      fontFamily: "Inter_400Regular",
      fontSize: 14,
      lineHeight: 21,
      color: colors.mutedForeground,
    },
    bnBlock: {
      marginTop: 4,
      padding: 12,
      borderRadius: 12,
      backgroundColor: colors.muted,
      gap: 4,
    },
    bnLabel: {
      fontFamily: "Inter_600SemiBold",
      fontSize: 10,
      letterSpacing: 0.6,
      color: colors.mutedForeground,
    },
    bnTitle: {
      fontFamily: "Inter_500Medium",
      fontSize: 15,
      color: colors.foreground,
    },
    bnSummary: {
      fontFamily: "Inter_400Regular",
      fontSize: 13,
      color: colors.mutedForeground,
    },
    actionRow: {
      marginTop: 4,
      flexDirection: "row",
      alignItems: "center",
      gap: 16,
    },
    actionBtn: {
      flexDirection: "row",
      alignItems: "center",
      gap: 4,
    },
    actionText: {
      fontFamily: "Inter_500Medium",
      fontSize: 13,
      color: colors.mutedForeground,
    },
    center: {
      flex: 1,
      alignItems: "center",
      justifyContent: "center",
      gap: 8,
      padding: 24,
    },
    emptyTitle: {
      fontFamily: "Inter_600SemiBold",
      fontSize: 15,
      color: colors.foreground,
    },
    emptyHint: {
      fontFamily: "Inter_400Regular",
      fontSize: 13,
      color: colors.mutedForeground,
      textAlign: "center",
    },
    retryBtn: {
      marginTop: 8,
      paddingHorizontal: 16,
      paddingVertical: 8,
      borderRadius: 10,
      backgroundColor: colors.primary,
    },
    retryBtnText: {
      fontFamily: "Inter_600SemiBold",
      fontSize: 13,
      color: "#fff",
    },
  });
}
