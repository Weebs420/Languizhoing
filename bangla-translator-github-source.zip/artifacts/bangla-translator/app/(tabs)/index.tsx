import { Feather } from "@expo/vector-icons";
import * as Clipboard from "expo-clipboard";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import React, { useCallback, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-controller";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useTranslateBangla } from "@workspace/api-client-react";

import { useColors } from "@/hooks/useColors";

type Tone = "casual" | "neutral" | "formal";
type CopyField = "translation" | "literal" | "spanish" | "bangla";

const TONES: { id: Tone; label: string; hint: string }[] = [
  { id: "casual", label: "Casual", hint: "Friend mode" },
  { id: "neutral", label: "Neutral", hint: "Everyday" },
  { id: "formal", label: "Formal", hint: "Polished" },
];

const SAMPLES = [
  "ভাই, আজকে অফিসে অনেক প্যারা গেছে। চিল করতে চাই, চলো কোথাও ঘুরে আসি।",
  "তুমি কাল আসবা, তাই না?",
  "আমার জন্য একটু wait করো, আমি প্রায় চলে এসেছি।",
  "পরীক্ষায় কোপ দিয়া আসছি!",
];

export default function TranslatorScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const styles = useMemo(() => createStyles(colors), [colors]);

  const [text, setText] = useState("");
  const [tone, setTone] = useState<Tone>("neutral");
  const [copiedField, setCopiedField] = useState<CopyField | null>(null);

  const mutation = useTranslateBangla();
  const result = mutation.data;

  const onTranslate = useCallback(() => {
    if (!text.trim() || mutation.isPending) return;
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    mutation.mutate({ data: { text: text.trim(), tone } });
  }, [text, tone, mutation]);

  const onClear = useCallback(() => {
    setText("");
    mutation.reset();
  }, [mutation]);

  const onCopy = useCallback(
    async (value: string, field: CopyField) => {
      await Clipboard.setStringAsync(value);
      if (Platform.OS !== "web") {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
      setCopiedField(field);
      setTimeout(() => setCopiedField(null), 1500);
    },
    [],
  );

  const onUseSample = useCallback((sample: string) => {
    setText(sample);
    mutation.reset();
  }, [mutation]);

  const webTopInset = Platform.OS === "web" ? 67 : insets.top;
  const webBottomInset = Platform.OS === "web" ? 34 : insets.bottom;

  const errorMessage =
    mutation.error instanceof Error ? mutation.error.message : null;

  return (
    <View style={[styles.root, { paddingTop: webTopInset }]}>
      <LinearGradient
        colors={["#0f766e", "#0ea5a4"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.header}
      >
        <View style={styles.headerRow}>
          <View style={styles.brandMark}>
            <Text style={styles.brandMarkText}>বE</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.headerTitle}>Bangla → American</Text>
            <Text style={styles.headerSubtitle}>
              Native-sounding translations, idioms and all
            </Text>
          </View>
        </View>
      </LinearGradient>

      <KeyboardAwareScrollView
        style={styles.scroll}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: webBottomInset + 32 },
        ]}
        keyboardShouldPersistTaps="handled"
        bottomOffset={20}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Text style={styles.cardLabel}>Bangla</Text>
            {text.length > 0 ? (
              <Pressable
                onPress={onClear}
                style={({ pressed }) => [styles.clearBtn, pressed && { opacity: 0.6 }]}
                hitSlop={8}
              >
                <Feather name="x" size={14} color={colors.mutedForeground} />
                <Text style={styles.clearBtnText}>Clear</Text>
              </Pressable>
            ) : null}
          </View>
          <TextInput
            value={text}
            onChangeText={setText}
            placeholder="এখানে বাংলায় লিখুন..."
            placeholderTextColor={colors.mutedForeground}
            multiline
            style={styles.input}
            textAlignVertical="top"
            scrollEnabled={false}
          />
          <View style={styles.cardFooter}>
            <Text style={styles.charCount}>{text.length} / 4000</Text>
          </View>
        </View>

        <View style={styles.toneRow}>
          {TONES.map((t) => {
            const active = tone === t.id;
            return (
              <Pressable
                key={t.id}
                onPress={() => {
                  setTone(t.id);
                  if (Platform.OS !== "web") {
                    Haptics.selectionAsync();
                  }
                }}
                style={({ pressed }) => [
                  styles.toneChip,
                  active && styles.toneChipActive,
                  pressed && { opacity: 0.85 },
                ]}
              >
                <Text style={[styles.toneLabel, active && styles.toneLabelActive]}>
                  {t.label}
                </Text>
                <Text
                  style={[styles.toneHint, active && styles.toneHintActive]}
                >
                  {t.hint}
                </Text>
              </Pressable>
            );
          })}
        </View>

        <Pressable
          onPress={onTranslate}
          disabled={!text.trim() || mutation.isPending}
          style={({ pressed }) => [
            styles.translateBtn,
            (!text.trim() || mutation.isPending) && styles.translateBtnDisabled,
            pressed && { transform: [{ scale: 0.98 }] },
          ]}
        >
          {mutation.isPending ? (
            <>
              <ActivityIndicator color={colors.primaryForeground} size="small" />
              <Text style={styles.translateBtnText}>Translating…</Text>
            </>
          ) : (
            <>
              <Feather
                name="arrow-down"
                size={18}
                color={colors.primaryForeground}
              />
              <Text style={styles.translateBtnText}>Translate</Text>
            </>
          )}
        </Pressable>

        {errorMessage ? (
          <View style={styles.errorCard}>
            <Feather name="alert-circle" size={16} color={colors.destructive} />
            <Text style={styles.errorText} numberOfLines={3}>
              {errorMessage}
            </Text>
            <Pressable
              onPress={onTranslate}
              style={({ pressed }) => [
                styles.retryBtn,
                pressed && { opacity: 0.7 },
              ]}
            >
              <Text style={styles.retryBtnText}>Retry</Text>
            </Pressable>
          </View>
        ) : null}

        {result ? (
          <>
            <View style={[styles.card, styles.dictionaryCard]}>
              <View style={styles.dictionaryHeader}>
                <View style={styles.resultLabelRow}>
                  <Feather name="book-open" size={15} color={colors.primary} />
                  <Text style={styles.cardLabel}>Dictionary preview</Text>
                </View>
                <Text style={styles.dictionaryHint}>Same source, three languages</Text>
              </View>
              {[
                { key: "bangla" as const, label: "Bangla", value: text },
                {
                  key: "translation" as const,
                  label: "American English",
                  value: result.translation,
                },
                { key: "spanish" as const, label: "Spanish", value: result.spanish },
              ].map((row, index) => (
                <React.Fragment key={row.key}>
                  {index > 0 ? <View style={styles.dictionaryDivider} /> : null}
                  <View style={styles.dictionaryRow}>
                    <View style={styles.dictionaryRowText}>
                      <Text style={styles.dictionaryLabel}>{row.label}</Text>
                      <Text style={styles.dictionaryValue}>{row.value}</Text>
                    </View>
                    <Pressable
                      onPress={() => onCopy(row.value, row.key)}
                      style={({ pressed }) => [
                        styles.dictionaryCopyBtn,
                        pressed && { opacity: 0.55 },
                      ]}
                      hitSlop={8}
                      accessibilityLabel={`Copy ${row.label}`}
                    >
                      <Feather
                        name={copiedField === row.key ? "check" : "copy"}
                        size={15}
                        color={
                          copiedField === row.key
                            ? colors.primary
                            : colors.mutedForeground
                        }
                      />
                    </Pressable>
                  </View>
                </React.Fragment>
              ))}
            </View>

            <View style={[styles.card, styles.resultCard]}>
              <View style={styles.cardHeader}>
                <View style={styles.resultLabelRow}>
                  <View style={styles.resultDot} />
                  <Text style={styles.cardLabel}>American English</Text>
                </View>
                <Pressable
                  onPress={() => onCopy(result.translation, "translation")}
                  style={({ pressed }) => [
                    styles.copyBtn,
                    pressed && { opacity: 0.6 },
                  ]}
                  hitSlop={8}
                >
                  <Feather
                    name={copiedField === "translation" ? "check" : "copy"}
                    size={14}
                    color={
                      copiedField === "translation"
                        ? colors.primary
                        : colors.mutedForeground
                    }
                  />
                  <Text
                    style={[
                      styles.copyBtnText,
                      copiedField === "translation" && {
                        color: colors.primary,
                      },
                    ]}
                  >
                    {copiedField === "translation" ? "Copied" : "Copy"}
                  </Text>
                </Pressable>
              </View>
              <Text style={styles.translationText}>{result.translation}</Text>
            </View>

            {result.literal ? (
              <View style={styles.card}>
                <View style={styles.cardHeader}>
                  <Text style={styles.cardLabelMuted}>Literal</Text>
                  <Pressable
                    onPress={() => onCopy(result.literal, "literal")}
                    style={({ pressed }) => [
                      styles.copyBtn,
                      pressed && { opacity: 0.6 },
                    ]}
                    hitSlop={8}
                  >
                    <Feather
                      name={copiedField === "literal" ? "check" : "copy"}
                      size={14}
                      color={
                        copiedField === "literal"
                          ? colors.primary
                          : colors.mutedForeground
                      }
                    />
                  </Pressable>
                </View>
                <Text style={styles.literalText}>{result.literal}</Text>
              </View>
            ) : null}

            {result.notes && result.notes.length > 0 ? (
              <View style={styles.notesCard}>
                <View style={styles.notesHeader}>
                  <Feather name="book-open" size={14} color={colors.accentForeground} />
                  <Text style={styles.notesTitle}>Translator's notes</Text>
                </View>
                {result.notes.map((note, i) => (
                  <View key={i} style={styles.noteRow}>
                    <Text style={styles.noteBullet}>•</Text>
                    <Text style={styles.noteText}>{note}</Text>
                  </View>
                ))}
              </View>
            ) : null}
          </>
        ) : !mutation.isPending && !errorMessage ? (
          <View style={styles.samplesSection}>
            <Text style={styles.samplesTitle}>Try a sample</Text>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.samplesRow}
            >
              {SAMPLES.map((s, i) => (
                <Pressable
                  key={i}
                  onPress={() => onUseSample(s)}
                  style={({ pressed }) => [
                    styles.sampleChip,
                    pressed && { opacity: 0.7 },
                  ]}
                >
                  <Text style={styles.sampleText} numberOfLines={3}>
                    {s}
                  </Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>
        ) : null}
      </KeyboardAwareScrollView>
    </View>
  );
}

function createStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    root: {
      flex: 1,
      backgroundColor: colors.background,
    },
    header: {
      paddingHorizontal: 20,
      paddingTop: 18,
      paddingBottom: 22,
      borderBottomLeftRadius: 24,
      borderBottomRightRadius: 24,
    },
    headerRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 14,
    },
    brandMark: {
      width: 44,
      height: 44,
      borderRadius: 12,
      backgroundColor: "rgba(255,255,255,0.18)",
      alignItems: "center",
      justifyContent: "center",
    },
    brandMarkText: {
      fontFamily: "Inter_700Bold",
      color: "#ffffff",
      fontSize: 18,
      letterSpacing: -0.5,
    },
    headerTitle: {
      fontFamily: "Inter_700Bold",
      fontSize: 20,
      color: "#ffffff",
      letterSpacing: -0.4,
    },
    headerSubtitle: {
      fontFamily: "Inter_400Regular",
      fontSize: 13,
      color: "rgba(255,255,255,0.85)",
      marginTop: 2,
    },
    scroll: {
      flex: 1,
    },
    scrollContent: {
      padding: 16,
      gap: 14,
    },
    card: {
      backgroundColor: colors.card,
      borderRadius: colors.radius,
      padding: 16,
      borderWidth: 1,
      borderColor: colors.border,
    },
    resultCard: {
      borderColor: colors.primary,
      borderWidth: 1.5,
    },
    dictionaryCard: {
      borderColor: colors.primary,
      borderWidth: 1.5,
      gap: 0,
    },
    dictionaryHeader: {
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      gap: 10,
      marginBottom: 4,
    },
    dictionaryHint: {
      flexShrink: 1,
      fontFamily: "Inter_400Regular",
      fontSize: 10,
      color: colors.mutedForeground,
      textAlign: "right",
    },
    dictionaryRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      paddingVertical: 12,
    },
    dictionaryRowText: {
      flex: 1,
      gap: 4,
    },
    dictionaryLabel: {
      fontFamily: "Inter_600SemiBold",
      fontSize: 10,
      letterSpacing: 0.8,
      color: colors.mutedForeground,
      textTransform: "uppercase",
    },
    dictionaryValue: {
      fontFamily: "Inter_500Medium",
      fontSize: 16,
      lineHeight: 23,
      color: colors.foreground,
    },
    dictionaryDivider: {
      height: 1,
      backgroundColor: colors.border,
    },
    dictionaryCopyBtn: {
      padding: 6,
    },
    cardHeader: {
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 10,
    },
    cardLabel: {
      fontFamily: "Inter_600SemiBold",
      fontSize: 12,
      letterSpacing: 0.6,
      color: colors.foreground,
      textTransform: "uppercase",
    },
    cardLabelMuted: {
      fontFamily: "Inter_500Medium",
      fontSize: 12,
      letterSpacing: 0.6,
      color: colors.mutedForeground,
      textTransform: "uppercase",
    },
    resultLabelRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
    },
    resultDot: {
      width: 8,
      height: 8,
      borderRadius: 4,
      backgroundColor: colors.primary,
    },
    clearBtn: {
      flexDirection: "row",
      alignItems: "center",
      gap: 4,
      paddingHorizontal: 8,
      paddingVertical: 4,
      borderRadius: 8,
      backgroundColor: colors.muted,
    },
    clearBtnText: {
      fontFamily: "Inter_500Medium",
      fontSize: 12,
      color: colors.mutedForeground,
    },
    input: {
      fontFamily: "Inter_400Regular",
      fontSize: 17,
      lineHeight: 26,
      color: colors.foreground,
      minHeight: 120,
      padding: 0,
      ...(Platform.OS === "web" ? ({ outlineStyle: "none" } as object) : {}),
    },
    cardFooter: {
      marginTop: 8,
      alignItems: "flex-end",
    },
    charCount: {
      fontFamily: "Inter_400Regular",
      fontSize: 11,
      color: colors.mutedForeground,
    },
    toneRow: {
      flexDirection: "row",
      gap: 8,
    },
    toneChip: {
      flex: 1,
      paddingVertical: 10,
      paddingHorizontal: 12,
      borderRadius: 12,
      borderWidth: 1,
      borderColor: colors.border,
      backgroundColor: colors.card,
      alignItems: "center",
    },
    toneChipActive: {
      backgroundColor: colors.foreground,
      borderColor: colors.foreground,
    },
    toneLabel: {
      fontFamily: "Inter_600SemiBold",
      fontSize: 14,
      color: colors.foreground,
    },
    toneLabelActive: {
      color: "#ffffff",
    },
    toneHint: {
      fontFamily: "Inter_400Regular",
      fontSize: 11,
      color: colors.mutedForeground,
      marginTop: 2,
    },
    toneHintActive: {
      color: "rgba(255,255,255,0.7)",
    },
    translateBtn: {
      backgroundColor: colors.primary,
      borderRadius: 14,
      paddingVertical: 16,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      gap: 10,
      shadowColor: colors.primary,
      shadowOpacity: 0.25,
      shadowRadius: 12,
      shadowOffset: { width: 0, height: 6 },
      elevation: 4,
    },
    translateBtnDisabled: {
      backgroundColor: colors.muted,
      shadowOpacity: 0,
      elevation: 0,
    },
    translateBtnText: {
      fontFamily: "Inter_600SemiBold",
      fontSize: 16,
      color: colors.primaryForeground,
    },
    errorCard: {
      backgroundColor: "#fef2f2",
      borderRadius: 12,
      padding: 14,
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      borderWidth: 1,
      borderColor: "#fecaca",
    },
    errorText: {
      flex: 1,
      fontFamily: "Inter_400Regular",
      fontSize: 13,
      color: "#7f1d1d",
    },
    retryBtn: {
      paddingHorizontal: 12,
      paddingVertical: 6,
      borderRadius: 8,
      backgroundColor: colors.destructive,
    },
    retryBtnText: {
      fontFamily: "Inter_600SemiBold",
      fontSize: 12,
      color: "#ffffff",
    },
    copyBtn: {
      flexDirection: "row",
      alignItems: "center",
      gap: 4,
      paddingHorizontal: 8,
      paddingVertical: 4,
      borderRadius: 8,
    },
    copyBtnText: {
      fontFamily: "Inter_500Medium",
      fontSize: 12,
      color: colors.mutedForeground,
    },
    translationText: {
      fontFamily: "Inter_500Medium",
      fontSize: 19,
      lineHeight: 28,
      color: colors.foreground,
      letterSpacing: -0.2,
    },
    literalText: {
      fontFamily: "Inter_400Regular",
      fontSize: 15,
      lineHeight: 23,
      color: colors.mutedForeground,
      fontStyle: "italic",
    },
    notesCard: {
      backgroundColor: colors.accent,
      borderRadius: colors.radius,
      padding: 14,
      gap: 8,
    },
    notesHeader: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
      marginBottom: 4,
    },
    notesTitle: {
      fontFamily: "Inter_600SemiBold",
      fontSize: 12,
      letterSpacing: 0.6,
      textTransform: "uppercase",
      color: colors.accentForeground,
    },
    noteRow: {
      flexDirection: "row",
      gap: 8,
    },
    noteBullet: {
      fontFamily: "Inter_700Bold",
      fontSize: 14,
      color: colors.accentForeground,
      lineHeight: 20,
    },
    noteText: {
      flex: 1,
      fontFamily: "Inter_400Regular",
      fontSize: 14,
      lineHeight: 20,
      color: colors.accentForeground,
    },
    samplesSection: {
      marginTop: 4,
      gap: 10,
    },
    samplesTitle: {
      fontFamily: "Inter_600SemiBold",
      fontSize: 13,
      color: colors.mutedForeground,
      paddingHorizontal: 4,
    },
    samplesRow: {
      gap: 10,
      paddingRight: 16,
    },
    sampleChip: {
      width: 220,
      padding: 12,
      borderRadius: 12,
      backgroundColor: colors.card,
      borderWidth: 1,
      borderColor: colors.border,
    },
    sampleText: {
      fontFamily: "Inter_400Regular",
      fontSize: 14,
      lineHeight: 21,
      color: colors.foreground,
    },
  });
}
