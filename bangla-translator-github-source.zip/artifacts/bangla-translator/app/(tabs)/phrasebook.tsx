import { Feather } from "@expo/vector-icons";
import * as Clipboard from "expo-clipboard";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import React, { useMemo, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useListPhrasebook } from "@workspace/api-client-react";

import { useColors } from "@/hooks/useColors";

const CATEGORY_FILTERS = [
  { id: undefined, label: "All" },
  { id: "slang", label: "Slang" },
  { id: "genz", label: "Gen Z" },
  { id: "idiom", label: "Idiom" },
  { id: "banglish", label: "Banglish" },
  { id: "regional", label: "Regional" },
  { id: "filler", label: "Fillers" },
  { id: "interjection", label: "Interjections" },
] as const;

type Entry = {
  id: number;
  bangla: string;
  english: string;
  category: string;
  example?: string | null;
};

export default function PhrasebookScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const styles = useMemo(() => createStyles(colors), [colors]);

  const [category, setCategory] = useState<string | undefined>(undefined);
  const [search, setSearch] = useState("");
  const [copiedId, setCopiedId] = useState<number | null>(null);

  const query = useListPhrasebook({ category, limit: 200 });
  const items = (query.data?.items ?? []) as Entry[];

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return items;
    return items.filter(
      (i) =>
        i.bangla.toLowerCase().includes(q) ||
        i.english.toLowerCase().includes(q) ||
        (i.example ?? "").toLowerCase().includes(q),
    );
  }, [items, search]);

  const onCopy = async (entry: Entry) => {
    await Clipboard.setStringAsync(`${entry.bangla} — ${entry.english}`);
    if (Platform.OS !== "web") {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
    setCopiedId(entry.id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const webTopInset = Platform.OS === "web" ? 67 : insets.top;

  return (
    <View style={[styles.root, { paddingTop: webTopInset }]}>
      <LinearGradient
        colors={["#0f766e", "#0ea5a4"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.header}
      >
        <Text style={styles.headerTitle}>Phrasebook</Text>
        <Text style={styles.headerSubtitle}>
          Bangla idioms, slang, and Gen Z phrases — auto-grown daily
        </Text>
        <View style={styles.searchBox}>
          <Feather name="search" size={16} color="rgba(255,255,255,0.85)" />
          <TextInput
            value={search}
            onChangeText={setSearch}
            placeholder="Search Bangla or English…"
            placeholderTextColor="rgba(255,255,255,0.65)"
            style={styles.searchInput}
          />
        </View>
      </LinearGradient>

      <View style={styles.filterRow}>
        <FlatList
          data={CATEGORY_FILTERS}
          keyExtractor={(item) => item.id ?? "all"}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filterContent}
          renderItem={({ item }) => {
            const active = category === item.id;
            return (
              <Pressable
                onPress={() => {
                  setCategory(item.id);
                  if (Platform.OS !== "web") Haptics.selectionAsync();
                }}
                style={({ pressed }) => [
                  styles.filterChip,
                  active && styles.filterChipActive,
                  pressed && { opacity: 0.85 },
                ]}
              >
                <Text
                  style={[
                    styles.filterLabel,
                    active && styles.filterLabelActive,
                  ]}
                >
                  {item.label}
                </Text>
              </Pressable>
            );
          }}
        />
      </View>

      {query.isPending ? (
        <View style={styles.center}>
          <ActivityIndicator color={colors.primary} />
        </View>
      ) : query.isError ? (
        <View style={styles.center}>
          <Text style={styles.emptyTitle}>Couldn't load phrasebook</Text>
          <Pressable
            onPress={() => query.refetch()}
            style={({ pressed }) => [
              styles.retryBtn,
              pressed && { opacity: 0.7 },
            ]}
          >
            <Text style={styles.retryBtnText}>Retry</Text>
          </Pressable>
        </View>
      ) : filtered.length === 0 ? (
        <View style={styles.center}>
          <Feather name="inbox" size={28} color={colors.mutedForeground} />
          <Text style={styles.emptyTitle}>Nothing here yet</Text>
          <Text style={styles.emptyHint}>
            The data pipeline will fill this in soon.
          </Text>
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <Pressable onPress={() => onCopy(item)} style={styles.entryCard}>
              <View style={styles.entryHeader}>
                <Text style={styles.bangla}>{item.bangla}</Text>
                <View style={styles.categoryPill}>
                  <Text style={styles.categoryText}>{item.category}</Text>
                </View>
              </View>
              <Text style={styles.english}>{item.english}</Text>
              {item.example ? (
                <Text style={styles.example}>"{item.example}"</Text>
              ) : null}
              <View style={styles.copyRow}>
                <Feather
                  name={copiedId === item.id ? "check" : "copy"}
                  size={12}
                  color={
                    copiedId === item.id
                      ? colors.primary
                      : colors.mutedForeground
                  }
                />
                <Text
                  style={[
                    styles.copyHint,
                    copiedId === item.id && { color: colors.primary },
                  ]}
                >
                  {copiedId === item.id ? "Copied" : "Tap to copy"}
                </Text>
              </View>
            </Pressable>
          )}
          refreshing={query.isFetching}
          onRefresh={() => query.refetch()}
        />
      )}
    </View>
  );
}

function createStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: colors.background },
    header: {
      paddingHorizontal: 20,
      paddingTop: 18,
      paddingBottom: 18,
      borderBottomLeftRadius: 24,
      borderBottomRightRadius: 24,
      gap: 6,
    },
    headerTitle: {
      fontFamily: "Inter_700Bold",
      fontSize: 22,
      color: "#fff",
      letterSpacing: -0.4,
    },
    headerSubtitle: {
      fontFamily: "Inter_400Regular",
      fontSize: 13,
      color: "rgba(255,255,255,0.85)",
    },
    searchBox: {
      marginTop: 12,
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
      backgroundColor: "rgba(255,255,255,0.18)",
      borderRadius: 10,
      paddingHorizontal: 12,
      paddingVertical: 8,
    },
    searchInput: {
      flex: 1,
      fontFamily: "Inter_400Regular",
      fontSize: 14,
      color: "#fff",
      ...(Platform.OS === "web" ? ({ outlineStyle: "none" } as object) : {}),
    },
    filterRow: { paddingTop: 12 },
    filterContent: {
      paddingHorizontal: 12,
      gap: 8,
    },
    filterChip: {
      paddingHorizontal: 14,
      paddingVertical: 8,
      borderRadius: 999,
      backgroundColor: colors.card,
      borderWidth: 1,
      borderColor: colors.border,
    },
    filterChipActive: {
      backgroundColor: colors.foreground,
      borderColor: colors.foreground,
    },
    filterLabel: {
      fontFamily: "Inter_500Medium",
      fontSize: 12,
      color: colors.foreground,
    },
    filterLabelActive: { color: "#fff" },
    listContent: { padding: 16, gap: 12, paddingBottom: 80 },
    entryCard: {
      backgroundColor: colors.card,
      borderRadius: colors.radius,
      padding: 14,
      borderWidth: 1,
      borderColor: colors.border,
      gap: 6,
    },
    entryHeader: {
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "flex-start",
      gap: 8,
    },
    bangla: {
      flex: 1,
      fontFamily: "Inter_600SemiBold",
      fontSize: 17,
      color: colors.foreground,
    },
    categoryPill: {
      backgroundColor: colors.muted,
      paddingHorizontal: 8,
      paddingVertical: 3,
      borderRadius: 6,
    },
    categoryText: {
      fontFamily: "Inter_500Medium",
      fontSize: 10,
      letterSpacing: 0.5,
      textTransform: "uppercase",
      color: colors.mutedForeground,
    },
    english: {
      fontFamily: "Inter_500Medium",
      fontSize: 15,
      color: colors.primary,
    },
    example: {
      fontFamily: "Inter_400Regular",
      fontSize: 13,
      color: colors.mutedForeground,
      fontStyle: "italic",
      marginTop: 2,
    },
    copyRow: {
      marginTop: 4,
      flexDirection: "row",
      alignItems: "center",
      gap: 4,
    },
    copyHint: {
      fontFamily: "Inter_400Regular",
      fontSize: 11,
      color: colors.mutedForeground,
    },
    center: {
      flex: 1,
      alignItems: "center",
      justifyContent: "center",
      gap: 8,
      padding: 24,
    },
    emptyTitle: {
      fontFamily: "Inter_600SemiBold",
      fontSize: 15,
      color: colors.foreground,
    },
    emptyHint: {
      fontFamily: "Inter_400Regular",
      fontSize: 13,
      color: colors.mutedForeground,
      textAlign: "center",
    },
    retryBtn: {
      marginTop: 8,
      paddingHorizontal: 16,
      paddingVertical: 8,
      borderRadius: 10,
      backgroundColor: colors.primary,
    },
    retryBtnText: {
      fontFamily: "Inter_600SemiBold",
      fontSize: 13,
      color: "#fff",
    },
  });
}
