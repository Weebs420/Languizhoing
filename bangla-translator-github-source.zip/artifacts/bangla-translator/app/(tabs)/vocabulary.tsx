import { Feather } from "@expo/vector-icons";
import * as Clipboard from "expo-clipboard";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import React, { useMemo, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Linking,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useListVocabulary } from "@workspace/api-client-react";

import { useColors } from "@/hooks/useColors";

const LEVEL_FILTERS = [
  { id: undefined, label: "All" },
  { id: "a1", label: "A1" },
  { id: "a2", label: "A2" },
  { id: "b1", label: "B1" },
  { id: "b2", label: "B2" },
  { id: "c1", label: "C1" },
] as const;

const LIST_FILTERS = [
  { id: undefined, label: "Both" },
  { id: "3000", label: "Oxford 3000" },
  { id: "5000", label: "Oxford 5000" },
] as const;

const LEVEL_COLOR: Record<string, string> = {
  a1: "#16a34a",
  a2: "#0d9488",
  b1: "#0284c7",
  b2: "#7c3aed",
  c1: "#db2777",
};

const OXFORD_BASE = "https://www.oxfordlearnersdictionaries.com";

type Entry = {
  id: number;
  word: string;
  pos: string;
  cefr: string;
  inOxford3000: boolean;
  inOxford5000: boolean;
  audioUk?: string | null;
  audioUs?: string | null;
  banglaMeaning?: string | null;
};

export default function VocabularyScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const styles = useMemo(() => createStyles(colors), [colors]);

  const [cefr, setCefr] = useState<string | undefined>(undefined);
  const [list, setList] = useState<string | undefined>(undefined);
  const [search, setSearch] = useState("");
  const [copiedId, setCopiedId] = useState<number | null>(null);

  const query = useListVocabulary({
    cefr: cefr as any,
    list: list as any,
    search: search.trim() || undefined,
    limit: 200,
  });
  const items = (query.data?.items ?? []) as Entry[];
  const total = query.data?.total ?? 0;

  const onCopy = async (entry: Entry) => {
    const text = entry.banglaMeaning
      ? `${entry.word} — ${entry.banglaMeaning}`
      : entry.word;
    await Clipboard.setStringAsync(text);
    if (Platform.OS !== "web") {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
    setCopiedId(entry.id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const onPlayAudio = (path: string | null | undefined) => {
    if (!path) return;
    const url = path.startsWith("http") ? path : `${OXFORD_BASE}${path}`;
    Linking.openURL(url).catch(() => {});
  };

  const webTopInset = Platform.OS === "web" ? 67 : insets.top;

  return (
    <View style={[styles.root, { paddingTop: webTopInset }]}>
      <LinearGradient
        colors={["#0f766e", "#0ea5a4"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.header}
      >
        <Text style={styles.headerTitle}>Vocabulary</Text>
        <Text style={styles.headerSubtitle}>
          Oxford 3000 & 5000 — the words every English learner needs
          {total ? ` · ${total.toLocaleString()} matches` : ""}
        </Text>
        <View style={styles.searchBox}>
          <Feather name="search" size={16} color="rgba(255,255,255,0.85)" />
          <TextInput
            value={search}
            onChangeText={setSearch}
            placeholder="Search words…"
            placeholderTextColor="rgba(255,255,255,0.65)"
            autoCapitalize="none"
            autoCorrect={false}
            style={styles.searchInput}
          />
        </View>
      </LinearGradient>

      <View style={styles.filterRow}>
        <FlatList
          data={LEVEL_FILTERS}
          keyExtractor={(item) => item.id ?? "all"}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filterContent}
          renderItem={({ item }) => {
            const active = cefr === item.id;
            return (
              <Pressable
                onPress={() => {
                  setCefr(item.id);
                  if (Platform.OS !== "web") Haptics.selectionAsync();
                }}
                style={({ pressed }) => [
                  styles.filterChip,
                  active && styles.filterChipActive,
                  pressed && { opacity: 0.85 },
                ]}
              >
                <Text
                  style={[
                    styles.filterLabel,
                    active && styles.filterLabelActive,
                  ]}
                >
                  {item.label}
                </Text>
              </Pressable>
            );
          }}
        />
      </View>

      <View style={styles.filterRowSecondary}>
        {LIST_FILTERS.map((item) => {
          const active = list === item.id;
          return (
            <Pressable
              key={item.id ?? "all"}
              onPress={() => {
                setList(item.id);
                if (Platform.OS !== "web") Haptics.selectionAsync();
              }}
              style={({ pressed }) => [
                styles.listChip,
                active && styles.listChipActive,
                pressed && { opacity: 0.85 },
              ]}
            >
              <Text
                style={[
                  styles.listLabel,
                  active && styles.listLabelActive,
                ]}
              >
                {item.label}
              </Text>
            </Pressable>
          );
        })}
      </View>

      {query.isPending ? (
        <View style={styles.center}>
          <ActivityIndicator color={colors.primary} />
        </View>
      ) : query.isError ? (
        <View style={styles.center}>
          <Text style={styles.emptyTitle}>Couldn't load vocabulary</Text>
          <Pressable
            onPress={() => query.refetch()}
            style={({ pressed }) => [
              styles.retryBtn,
              pressed && { opacity: 0.7 },
            ]}
          >
            <Text style={styles.retryBtnText}>Retry</Text>
          </Pressable>
        </View>
      ) : items.length === 0 ? (
        <View style={styles.center}>
          <Feather name="inbox" size={28} color={colors.mutedForeground} />
          <Text style={styles.emptyTitle}>No words match</Text>
          <Text style={styles.emptyHint}>Try clearing filters or search.</Text>
        </View>
      ) : (
        <FlatList
          data={items}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => {
            const levelColor = LEVEL_COLOR[item.cefr] ?? colors.primary;
            return (
              <Pressable onPress={() => onCopy(item)} style={styles.entryCard}>
                <View style={styles.entryHeader}>
                  <View style={styles.wordCol}>
                    <Text style={styles.word}>{item.word}</Text>
                    <Text style={styles.pos}>{item.pos}</Text>
                  </View>
                  <View
                    style={[
                      styles.levelBadge,
                      { backgroundColor: levelColor },
                    ]}
                  >
                    <Text style={styles.levelText}>
                      {item.cefr.toUpperCase()}
                    </Text>
                  </View>
                </View>
                {item.banglaMeaning ? (
                  <Text style={styles.bangla}>{item.banglaMeaning}</Text>
                ) : null}
                <View style={styles.metaRow}>
                  {item.inOxford3000 ? (
                    <View style={styles.tag}>
                      <Text style={styles.tagText}>Oxford 3000</Text>
                    </View>
                  ) : item.inOxford5000 ? (
                    <View style={styles.tag}>
                      <Text style={styles.tagText}>Oxford 5000</Text>
                    </View>
                  ) : null}

                  {item.audioUs ? (
                    <Pressable
                      hitSlop={8}
                      onPress={() => onPlayAudio(item.audioUs)}
                      style={({ pressed }) => [
                        styles.audioBtn,
                        pressed && { opacity: 0.7 },
                      ]}
                    >
                      <Feather name="volume-2" size={12} color={colors.primary} />
                      <Text style={styles.audioText}>US</Text>
                    </Pressable>
                  ) : null}

                  {item.audioUk ? (
                    <Pressable
                      hitSlop={8}
                      onPress={() => onPlayAudio(item.audioUk)}
                      style={({ pressed }) => [
                        styles.audioBtn,
                        pressed && { opacity: 0.7 },
                      ]}
                    >
                      <Feather name="volume-2" size={12} color={colors.mutedForeground} />
                      <Text style={[styles.audioText, { color: colors.mutedForeground }]}>
                        UK
                      </Text>
                    </Pressable>
                  ) : null}

                  <View style={{ flex: 1 }} />

                  <Feather
                    name={copiedId === item.id ? "check" : "copy"}
                    size={12}
                    color={
                      copiedId === item.id
                        ? colors.primary
                        : colors.mutedForeground
                    }
                  />
                  <Text
                    style={[
                      styles.copyHint,
                      copiedId === item.id && { color: colors.primary },
                    ]}
                  >
                    {copiedId === item.id ? "Copied" : "Tap to copy"}
                  </Text>
                </View>
              </Pressable>
            );
          }}
          refreshing={query.isFetching}
          onRefresh={() => query.refetch()}
        />
      )}
    </View>
  );
}

function createStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: colors.background },
    header: {
      paddingHorizontal: 20,
      paddingTop: 18,
      paddingBottom: 18,
      borderBottomLeftRadius: 24,
      borderBottomRightRadius: 24,
      gap: 6,
    },
    headerTitle: {
      fontFamily: "Inter_700Bold",
      fontSize: 22,
      color: "#fff",
      letterSpacing: -0.4,
    },
    headerSubtitle: {
      fontFamily: "Inter_400Regular",
      fontSize: 13,
      color: "rgba(255,255,255,0.85)",
    },
    searchBox: {
      marginTop: 12,
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
      backgroundColor: "rgba(255,255,255,0.18)",
      borderRadius: 10,
      paddingHorizontal: 12,
      paddingVertical: 8,
    },
    searchInput: {
      flex: 1,
      fontFamily: "Inter_400Regular",
      fontSize: 14,
      color: "#fff",
      ...(Platform.OS === "web" ? ({ outlineStyle: "none" } as object) : {}),
    },
    filterRow: { paddingTop: 12 },
    filterContent: {
      paddingHorizontal: 12,
      gap: 8,
    },
    filterChip: {
      paddingHorizontal: 14,
      paddingVertical: 8,
      borderRadius: 999,
      backgroundColor: colors.card,
      borderWidth: 1,
      borderColor: colors.border,
    },
    filterChipActive: {
      backgroundColor: colors.foreground,
      borderColor: colors.foreground,
    },
    filterLabel: {
      fontFamily: "Inter_500Medium",
      fontSize: 12,
      color: colors.foreground,
    },
    filterLabelActive: { color: "#fff" },
    filterRowSecondary: {
      flexDirection: "row",
      gap: 8,
      paddingHorizontal: 16,
      paddingTop: 8,
      paddingBottom: 4,
    },
    listChip: {
      paddingHorizontal: 12,
      paddingVertical: 6,
      borderRadius: 8,
      backgroundColor: colors.muted,
      borderWidth: 1,
      borderColor: colors.border,
    },
    listChipActive: {
      backgroundColor: colors.primary,
      borderColor: colors.primary,
    },
    listLabel: {
      fontFamily: "Inter_500Medium",
      fontSize: 11,
      color: colors.mutedForeground,
      letterSpacing: 0.3,
    },
    listLabelActive: { color: "#fff" },
    listContent: { padding: 16, gap: 10, paddingBottom: 80 },
    entryCard: {
      backgroundColor: colors.card,
      borderRadius: colors.radius,
      padding: 14,
      borderWidth: 1,
      borderColor: colors.border,
      gap: 8,
    },
    entryHeader: {
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      gap: 8,
    },
    wordCol: { flex: 1, gap: 2 },
    word: {
      fontFamily: "Inter_700Bold",
      fontSize: 18,
      color: colors.foreground,
    },
    pos: {
      fontFamily: "Inter_400Regular",
      fontSize: 12,
      color: colors.mutedForeground,
      fontStyle: "italic",
    },
    bangla: {
      fontFamily: "Inter_500Medium",
      fontSize: 15,
      color: colors.primary,
      lineHeight: 20,
    },
    levelBadge: {
      paddingHorizontal: 10,
      paddingVertical: 4,
      borderRadius: 6,
    },
    levelText: {
      fontFamily: "Inter_700Bold",
      fontSize: 11,
      letterSpacing: 0.6,
      color: "#fff",
    },
    metaRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
    },
    tag: {
      backgroundColor: colors.muted,
      paddingHorizontal: 8,
      paddingVertical: 3,
      borderRadius: 6,
    },
    tagText: {
      fontFamily: "Inter_500Medium",
      fontSize: 10,
      letterSpacing: 0.4,
      color: colors.mutedForeground,
      textTransform: "uppercase",
    },
    audioBtn: {
      flexDirection: "row",
      alignItems: "center",
      gap: 3,
      paddingHorizontal: 6,
      paddingVertical: 3,
      borderRadius: 6,
      backgroundColor: colors.muted,
    },
    audioText: {
      fontFamily: "Inter_600SemiBold",
      fontSize: 10,
      color: colors.primary,
      letterSpacing: 0.4,
    },
    copyHint: {
      fontFamily: "Inter_400Regular",
      fontSize: 11,
      color: colors.mutedForeground,
    },
    center: {
      flex: 1,
      alignItems: "center",
      justifyContent: "center",
      gap: 8,
      padding: 24,
    },
    emptyTitle: {
      fontFamily: "Inter_600SemiBold",
      fontSize: 15,
      color: colors.foreground,
    },
    emptyHint: {
      fontFamily: "Inter_400Regular",
      fontSize: 13,
      color: colors.mutedForeground,
      textAlign: "center",
    },
    retryBtn: {
      marginTop: 8,
      paddingHorizontal: 16,
      paddingVertical: 8,
      borderRadius: 10,
      backgroundColor: colors.primary,
    },
    retryBtnText: {
      fontFamily: "Inter_600SemiBold",
      fontSize: 13,
      color: "#fff",
    },
  });
}
